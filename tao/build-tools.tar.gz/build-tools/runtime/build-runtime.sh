#!/usr/bin/env bash
set -euo pipefail
kit=$(cd -- "$(dirname -- "$0")" && pwd)
image=${1:-localhost/tessera-tao:24.6.1-rocky10-runtime-r2}
application=localhost/tessera-awx-application-build:24.6.1-rocky10-i18n-r1
expected=34b72f5ee214ff82942f9d3fea0a5cd544056e82a57b0f2688fd625c0732fbee
actual=$(podman image inspect --format '{{.Id}}' "$application")
[[ ${actual#sha256:} == "$expected" ]] || { echo 'Application image identity mismatch' >&2; exit 2; }
reports=$(mktemp -d "$PWD/tao-runtime-build.XXXXXX")
printf 'Reports: %s\n' "$reports"
podman build --pull=never --jobs=1 --cpu-period=100000 --cpu-quota=200000 \
    --memory=7g --memory-swap=7g --build-arg "APPLICATION_IMAGE=$application" \
    -f "$kit/Containerfile.runtime" -t "$image" "$kit" 2>&1 | tee "$reports/build.log"
podman image inspect --format '{{.Id}}' "$image" | tee "$reports/image-id.txt"
podman run --rm --pull=never --network=none "$image" \
    python /usr/local/libexec/verify-tao-runtime.py 2>&1 | tee "$reports/verify.log"
printf 'Runtime candidate built. No cluster changes made. Reports: %s\n' "$reports"
