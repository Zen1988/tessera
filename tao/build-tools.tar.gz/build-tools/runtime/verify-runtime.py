import configparser
import importlib.metadata
import os
from pathlib import Path
import re
import shutil
import subprocess

assert os.getuid() == 1000 and os.getgid() == 0
assert importlib.metadata.version('awx') == '24.6.1'
import awx
import django, cryptography, lxml.etree, xmlsec, psycopg
assert '/build/' not in awx.__file__
for name in ('awx-manage', 'supervisord', 'dumb-init', 'nginx', 'rsyslogd',
             'wait-for-migrations', 'stop-supervisor', 'awx-python', 'rsyslog-4xx-recovery'):
    assert shutil.which(name), name
for component in ('web', 'task', 'rsyslog'):
    subprocess.run(['bash', '-n', f'/usr/bin/launch_awx_{component}.sh'], check=True)
    conf = configparser.RawConfigParser()
    conf.read(f'/etc/supervisord_{component}.conf')
    assert conf.has_section('supervisord')
    for section in conf.sections():
        if conf.has_option(section, 'command'):
            command = conf.get(section, 'command').split()[0]
            assert shutil.which(command), (section, command)
for directory in ('/var/lib/awx', '/var/lib/awx/rsyslog', '/var/run/supervisor',
                  '/var/run/awx-rsyslog', '/var/run/receptor', '/var/lib/nginx', '/var/log/tower'):
    assert os.access(directory, os.W_OK), directory
assert Path('/var/lib/awx/venv/awx').resolve() == Path('/opt/awx-compat')
root = Path(awx.__file__).parent / 'ui/build'
html = (root / 'index.html').read_text()
for name in re.findall(r"{% static '([^']+)' %}", html) + [
        'media/default.strings.json', 'media/logo-login.svg', 'media/logo-header.svg', 'media/favicon.svg']:
    assert (Path('/var/lib/awx/public/static') / name).read_bytes() == (root / 'static' / name).read_bytes(), name
assert 'favicon.svg' in html, 'Updated SVG favicon is not linked'
missing = []
for library in Path('/opt/awx-compat').rglob('*.so*'):
    if library.is_file():
        result = subprocess.run(['ldd', str(library)], capture_output=True, text=True)
        if 'not found' in result.stdout:
            missing.append((str(library), result.stdout))
assert not missing, missing
print('Runtime paths, UID/GID, native imports, linked libraries and collected assets verified')
