#!/usr/bin/env bash
set -euo pipefail
image=${1:-localhost/tessera-awx:24.6.1-rocky10-runtime-r1}
nginx_config=$(realpath "${2:-tao-nginx.conf}")
uwsgi_config=$(realpath "${3:-tao-uwsgi.ini}")
reports=$(mktemp -d "$PWD/tao-runtime-config.XXXXXX")
printf 'Reports: %s\n' "$reports"
podman image inspect --format '{{.Id}}' "$image" > "$reports/image-id.txt"
podman run --rm -i --pull=never --network=none --timeout=60 \
  -v "$nginx_config:/etc/nginx/nginx.conf:ro,Z" \
  -v "$uwsgi_config:/etc/tower/uwsgi.ini:ro,Z" \
  "$image" python - 2>&1 <<'PY' | tee "$reports/config-check.log"
import os
from pathlib import Path
import subprocess
import time
import urllib.request

assert os.getuid() == 1000
subprocess.run(['nginx', '-t'], check=True, timeout=10)
parsed = subprocess.run(
    ['/var/lib/awx/venv/awx/bin/uwsgi', '--ini', '/etc/tower/uwsgi.ini',
     '--get', 'socket', '--get', 'processes'],
    check=True, timeout=10, capture_output=True, text=True)
print(parsed.stderr, end='')
assert parsed.stdout.splitlines() == ['127.0.0.1:8050', '5'], parsed.stdout
print('uWSGI parsed operator socket and worker count without starting services')
process = subprocess.Popen(['nginx', '-g', 'daemon off;'])
try:
    url = 'http://127.0.0.1:8052/static/media/default.strings.json'
    for attempt in range(40):
        try:
            with urllib.request.urlopen(url, timeout=1) as response:
                assert response.status == 200
                assert response.read() == Path('/var/lib/awx/public/static/media/default.strings.json').read_bytes()
            break
        except (OSError, urllib.error.URLError):
            if process.poll() is not None:
                raise RuntimeError('nginx exited before serving static assets')
            time.sleep(0.25)
    else:
        raise RuntimeError('nginx did not serve the static asset within 10 seconds')
    print('Operator nginx configuration served exact branded static asset as UID1000')
finally:
    process.terminate()
    process.wait(timeout=10)
config = Path('/tmp/tao-rsyslog-check.conf')
config.write_text('module(load="imuxsock" SysSock.Use="off")\nmodule(load="omhttp")\naction(type="omfile" file="/dev/null")\n')
subprocess.run(['rsyslogd', '-N1', '-f', str(config)], check=True, timeout=10)
print('rsyslog imuxsock and omhttp modules validated')
print('Configuration smoke check passed; database-connected services not started')
PY
printf 'Send %s/config-check.log and image-id.txt\n' "$reports"
