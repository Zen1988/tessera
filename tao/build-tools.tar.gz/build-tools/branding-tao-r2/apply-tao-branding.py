"""Apply owner-supplied full logo and compact emblem to the i18n candidate."""
import argparse
from pathlib import Path
import shutil
import xml.etree.ElementTree as ET

parser = argparse.ArgumentParser()
parser.add_argument('source', type=Path)
args = parser.parse_args()
ui = args.source.resolve() / 'awx/ui'
assets = Path(__file__).resolve().parent
media = ui / 'public/static/media'
index = ui / 'public/index.html'
assert media.is_dir() and index.is_file(), 'Expected AWX UI public assets'
html = index.read_text()
assert 'favicon.ico' in html or 'favicon.svg' in html, 'Unexpected favicon template'
for name in ('logo-login.svg', 'logo-header.svg', 'favicon.svg'):
    ET.parse(assets / name)
for name in ('logo-login.svg', 'logo-header.svg', 'favicon.svg'):
    shutil.copyfile(assets / name, media / name)
html = html.replace('favicon.ico', 'favicon.svg').replace('image/x-icon', 'image/svg+xml')
index.write_text(html)
print('Full supplied logo: login; compact emblem: header and SVG favicon')
print('Existing favicon.ico retained as legacy fallback; modern browsers use linked favicon.svg')
print('Rebuild required; running cluster is unchanged')
