#!/usr/bin/env bash
set -euo pipefail
source_dir=$(realpath "${1:?Pass the ESLint10 AWX checkout}")
image=${2:-localhost/tessera-awx-application-build:24.6.1-rocky10-lingui4-r2}
scope=${3:-focused}
case "$scope" in
    focused|--all) ;;
    *) printf 'Third argument must be focused or --all\n' >&2; exit 2 ;;
esac
ui="$source_dir/awx/ui"
test -f "$ui/package-lock.json"
reports=$(mktemp -d "$PWD/tao-checkout-regression.XXXXXX")
printf 'Reports: %s\n' "$reports"
podman image inspect --format '{{.Id}}' "$image" > "$reports/image-id.txt"
sha256sum "$ui/package.json" "$ui/package-lock.json" > "$reports/ui-inputs.sha256"
status=0
podman run --rm --pull=never --timeout=1800 \
    -e TZ=UTC -e "TAO_TEST_SCOPE=$scope" \
    --cpu-period=100000 --cpu-quota=200000 --memory=7g --memory-swap=7g \
    -v "$ui:/source:ro,Z" -v "$reports:/reports:Z" "$image" \
    bash -euo pipefail -c '
        mkdir /tmp/tao-regression
        tar -C /source --exclude=./node_modules --exclude=./build --exclude=./coverage -cf - . |
            tar -xf - -C /tmp/tao-regression
        cd /tmp/tao-regression
        npm ci --no-audit --strict-peer-deps --engine-strict
        npm run prelint
        node <<\NODE
const fs = require("node:fs");
const path = require("node:path");
const { spawnSync } = require("node:child_process");
const groups = [
  "App.test.js",
  "components/AdHocCommands",
  "components/AddRole",
  "components/AppContainer",
  "components/SelectedList",
  "screens/Application",
  "screens/Inventory/InventoryEdit",
  "screens/Inventory/Inventory.test.js",
  "components/Schedule",
  "screens/Credential/shared/CredentialPlugins",
  "screens/Job/JobOutput",
  "screens/ActivityStream",
  "screens/WorkflowApproval",
  "components/WorkflowOutputNavigation",
  "components/CodeEditor",
  "screens/Setting/Subscription",
];
function walk(dir) {
  if (fs.statSync(dir).isFile()) return [dir];
  return fs.readdirSync(dir, { withFileTypes: true }).flatMap(entry => {
    const name = path.posix.join(dir, entry.name);
    if (entry.isDirectory()) return walk(name);
    return entry.isFile() && /\.test\.jsx?$/.test(name) ? [name] : [];
  });
}
const suites = (process.env.TAO_TEST_SCOPE === "--all" ? [""] : groups).flatMap(group => {
  const tests = walk(`src/${group}`).sort();
  if (!tests.length) throw new Error(`No tests in required group: ${group}`);
  return tests;
});
fs.writeFileSync("/reports/suites.txt", suites.join("\n") + "\n");
const results = [];
for (let offset = 0; offset < suites.length; offset += 15) {
  const batch = suites.slice(offset, offset + 15);
  const report = `/reports/batch-${offset / 15 + 1}.json`;
  console.log(`Running batch ${offset / 15 + 1}: ${batch.length} suites`);
  const run = spawnSync(process.execPath, [
    "node_modules/jest/bin/jest.js", "--config=jest.config.cjs",
    "--runInBand", "--runTestsByPath",
    "--json", `--outputFile=${report}`, ...batch,
  ], { stdio: "inherit", timeout: 240000 });
  results.push({ suites: batch, status: run.status, signal: run.signal,
    error: run.error?.message, report });
  if (run.status !== 0 && fs.existsSync(report) &&
      JSON.parse(fs.readFileSync(report, "utf8")).numTotalTests === 0) {
    console.error("No tests executed in failed batch; stopping to review harness failure.");
    break;
  }
}
fs.writeFileSync("/reports/batches.json", JSON.stringify(results, null, 2));
if (results.some(result => result.status !== 0)) process.exitCode = 1;
NODE
    ' > "$reports/regression.log" 2>&1 || status=$?
printf '%s\n' "$status" > "$reports/exit-code.txt"
tail -n 50 "$reports/regression.log"
printf 'Reports: %s (exit %s)\n' "$reports" "$status"
exit "$status"
