#!/usr/bin/env bash
set -euo pipefail
source_dir=$(realpath -e "${1:?Pass the verified core-js candidate}")
ui="$source_dir/awx/ui"
test -d "$ui/node_modules/@lingui/cli"
reports=$(mktemp -d "$PWD/tao-glob-callers.XXXXXX")
image=localhost/tessera-awx-application-build:24.6.1-rocky10-eslint10-r3
sha256sum "$ui/package.json" "$ui/package-lock.json" > "$reports/ui-inputs.sha256"
podman image inspect --format '{{.Id}}' "$image" > "$reports/image-id.txt"
podman run --rm -i --pull=never --network=none \
    -v "$ui:/source:ro,Z" -w /source "$image" python - \
    > "$reports/glob-callers.tar.gz" <<'PY'
from pathlib import Path
import tarfile
import sys
import json

root = Path.cwd()
lock = json.loads((root / 'package-lock.json').read_text())
names = {'@lingui/cli', 'babel-plugin-istanbul', 'test-exclude', 'glob'}
selected = {root / 'package.json', root / 'package-lock.json', root / '.linguirc'}
for name, metadata in lock['packages'].items():
    if not any(name.endswith('node_modules/' + package) for package in names):
        continue
    folder = root / name
    if not folder.is_dir():
        raise SystemExit('Installed dependency missing: ' + name)
    for path in folder.rglob('*'):
        relative = path.relative_to(folder)
        if 'node_modules' in relative.parts or not path.is_file():
            continue
        if path.suffix in ('.js', '.cjs', '.mjs', '.ts', '.json') and not path.name.endswith('.map'):
            selected.add(path)
with tarfile.open(fileobj=sys.stdout.buffer, mode='w|gz') as archive:
    for path in sorted(selected):
        if path.is_symlink() or not path.resolve().is_relative_to(root):
            raise SystemExit('Refusing source outside UI')
        archive.add(path, arcname=path.relative_to(root), recursive=False)
print(f'Collected {len(selected)} files', file=sys.stderr)
PY
sha256sum "$reports/glob-callers.tar.gz" > "$reports/glob-callers.sha256"
printf 'Send glob-callers.tar.gz and ui-inputs.sha256 from %s\n' "$reports"
