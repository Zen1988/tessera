"""Migrate removed matcher aliases and narrowly normalize one ICU assertion."""
from pathlib import Path
import re
import sys

if len(sys.argv) != 2:
    raise SystemExit('Usage: python3 fix-tao-jest30-tests.py <TAO checkout>')
ui = Path(sys.argv[1]) / 'awx/ui'
aliases = dict(zip(
    ('toBeCalled', 'toBeCalledTimes', 'toBeCalledWith', 'lastCalledWith',
     'nthCalledWith', 'toReturn', 'toReturnTimes', 'toReturnWith',
     'lastReturnedWith', 'nthReturnedWith', 'toThrowError'),
    ('toHaveBeenCalled', 'toHaveBeenCalledTimes', 'toHaveBeenCalledWith',
     'toHaveBeenLastCalledWith', 'toHaveBeenNthCalledWith', 'toHaveReturned',
     'toHaveReturnedTimes', 'toHaveReturnedWith', 'toHaveLastReturnedWith',
     'toHaveNthReturnedWith', 'toThrow')))
pattern = re.compile(r'\.(' + '|'.join(aliases) + r')(?=\s*\()')
updates = {}
for path in (ui / 'src').rglob('*.test.js'):
    original = path.read_bytes()
    updated = pattern.sub(lambda m: '.' + aliases[m[1]], original.decode('utf-8')).encode('utf-8')
    if updated != original:
        updates[path] = updated

env = ui / 'tao-jest-environment.cjs'
original = env.read_bytes()
line = b"      MessageChannel: require('node:worker_threads').MessageChannel,"
if original.count(line) > 1:
    raise SystemExit('Ambiguous MessageChannel declaration; no writes')
updated = b''.join(row for row in original.splitlines(keepends=True) if row.rstrip(b'\r\n') != line)
if updated != original:
    updates[env] = updated

schedule = ui / 'src/components/Schedule/ScheduleOccurrences/ScheduleOccurrences.test.js'
original = schedule.read_bytes()
text = updates.get(schedule, original).decode('utf-8')
normalizer = r".text().replace(/\u202f/g, ' ')"
if '3/16/2020, 4:00:00 AM' not in text:
    raise SystemExit('Known Schedule UTC assertion missing; no writes')
date_text = re.compile(r"wrapper\.find\(['\"]dd['\"]\)\.children\(\)\.at\([01]\)\.text\(\)")
if not date_text.search(text):
    raise SystemExit('Known Schedule date selectors missing; no writes')
updated = date_text.sub(
    lambda m: m[0] if text[m.end():].startswith(normalizer[len('.text()'):])
    else m[0] + normalizer[len('.text()'):], text).encode('utf-8')
if updated != original:
    updates[schedule] = updated
for path, data in updates.items():
    path.write_bytes(data)
    print(f'Updated {path}')
print(f'Updated {len(updates)} files')
