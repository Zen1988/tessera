import assert from 'node:assert/strict';
import { mkdtemp, writeFile, rm, cp } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { resolve, join } from 'node:path';
import { spawnSync } from 'node:child_process';
import { build, mergeConfig } from 'vite';
import config from './vite.config.mjs';

const temporary = await mkdtemp(join(tmpdir(), 'tao-i18n-'));
const entry = resolve('src/taoI18nProductionProbe.js');
try {
  await writeFile(entry, `export { i18n } from '@lingui/core';
export { dynamicActivate, locales } from './i18nLoader';
export { messages as englishMessages } from './locales/en/messages.mjs';
` , { flag: 'wx' });
  await writeFile(join(temporary, 'package.json'), '{"type":"module"}');
  await build(mergeConfig(config, {
    build: {
      outDir: temporary, emptyOutDir: false, manifest: false,
      rollupOptions: { input: entry, preserveEntrySignatures: 'strict',
        output: { entryFileNames: 'entry.js' } },
    },
  }));
  const script = `
import assert from 'node:assert/strict';
import { i18n, dynamicActivate, locales, englishMessages } from './entry.js';
console.log('Direct catalog keys:', Object.keys(englishMessages).length);
console.log('Direct username:', JSON.stringify(englishMessages['7sNhEz']));
for (const locale of Object.keys(locales)) {
  await dynamicActivate(locale);
  console.log('Activation diagnostics:', locale, i18n.locale, JSON.stringify(i18n._('7sNhEz')),
    'loaded locales', Object.keys(i18n.messages || {}),
    'current username', JSON.stringify((i18n.messages || {})['7sNhEz']));
  assert.equal(i18n.locale, locale);
  for (const id of ['7sNhEz', '8ZsakT', 'ADVQ46', 'AJe0w5']) {
    assert.notEqual(i18n._(id), id, locale + ': unresolved ' + id);
  }
}
await dynamicActivate('en');
assert.equal(i18n._('7sNhEz'), 'Username');
assert.equal(i18n._('8ZsakT'), 'Password');
assert.equal(i18n._('ADVQ46'), 'Log In');
assert.equal(i18n._('AJe0w5'), 'Please log in');
assert.equal(i18n._('+qDTyb', {brandName:'TESSERA'}), 'Welcome to TESSERA!');
console.log('Production Vite loader: all 8 locales activate; exact English login labels verified');
`;
  await writeFile(join(temporary, 'verify.mjs'), script);
  const result = spawnSync(process.execPath, [join(temporary, 'verify.mjs')], { stdio: 'inherit', timeout: 30000 });
  assert.equal(result.status, 0, 'Production catalog activation failed');
} finally {
  if (process.env.TAO_I18N_DIAGNOSTICS) {
    await cp(temporary, process.env.TAO_I18N_DIAGNOSTICS, { recursive: true });
    console.log('Saved emitted production probe:', process.env.TAO_I18N_DIAGNOSTICS);
  }
  await rm(entry, { force: true });
  await rm(temporary, { recursive: true, force: true });
}
