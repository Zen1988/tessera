#!/usr/bin/env bash
set -euo pipefail
candidate=$(realpath -e "${1:?Pass existing combined candidate}")
previous=$(realpath -e "${2:?Pass its preparation report directory}")
kit_dir=$(cd "$(dirname "$0")" && pwd)
reports=$(mktemp -d "$PWD/tao-remaining-validation.XXXXXX")
cp "$previous/consumers.before.json" "$previous/encoding-labels.json" "$previous/package-lock.before.json" "$reports/"
cp "$kit_dir/probe-tao-remaining.cjs" "$reports/"
printf 'Reports: %s\n' "$reports"
status=0
podman run --rm --pull=never --userns=keep-id --timeout=600 \
    -e npm_config_cache=/tmp/tao-npm-cache \
    -v "$candidate/awx/ui:/workspace:Z" -v "$reports:/reports:Z" -w /workspace \
    localhost/tessera-awx-application-build:24.6.1-rocky10-maintenance-glob-r1 \
    bash -euo pipefail -c '
        node <<\NODE
const fs=require("node:fs");
const p=require("./package.json");
const versions={"lodash.get":"4.4.2-tessera.1","lodash.isequal":"4.5.0-tessera.1","whatwg-encoding":"3.1.1-tessera.1"};
for(const [name,version] of Object.entries(versions)) {
 const spec="file:vendor/"+name+"-"+version+".tgz";
 if(p.overrides[name]!==spec && p.overrides[name]!=="$"+name) throw Error("Unexpected override: "+name);
 if(!fs.existsSync(spec.slice(5))) throw Error("Missing root vendor archive: "+spec);
 const section=name==="whatwg-encoding" ? "devDependencies" : "dependencies";
 if(p[section][name] && p[section][name]!==spec) throw Error("Existing direct dependency conflict");
}
for(const [name,version] of Object.entries(versions)) {
 const section=name==="whatwg-encoding" ? "devDependencies" : "dependencies";
 p[section][name]="file:vendor/"+name+"-"+version+".tgz";
 p.overrides[name]="$"+name;
}
fs.writeFileSync("package.json",JSON.stringify(p,null,2)+"\n");
NODE
        npm install --package-lock-only --ignore-scripts --no-audit --strict-peer-deps --engine-strict
        node <<\NODE
const fs=require("node:fs");
const before=require("/reports/package-lock.before.json").packages;
const after=require("./package-lock.json").packages;
const versions={"lodash.get":"4.4.2-tessera.1","lodash.isequal":"4.5.0-tessera.1","whatwg-encoding":"3.1.1-tessera.1"};
const changes=Object.keys({...before,...after}).filter(k=>before[k]?.version!==after[k]?.version)
 .map(k=>({path:k,before:before[k]?.version,after:after[k]?.version}));
fs.writeFileSync("/reports/lock-changes.json",JSON.stringify(changes,null,2));
for(const c of changes) if(!Object.keys(versions).some(n=>c.path.endsWith("node_modules/"+n))) throw Error("Unrelated version change: "+c.path);
for(const [key,pkg] of Object.entries(after)) {
 for(const [name,version] of Object.entries(versions)) if(key.endsWith("node_modules/"+name) &&
   (pkg.version!==version || !pkg.resolved?.startsWith("file:vendor/") || pkg.deprecated)) throw Error("Old registry implementation remains");
 if(pkg.deprecated) throw Error("Deprecated package remains: "+key);
 if(key.endsWith("node_modules/popper.js") || key.endsWith("node_modules/tippy.js") || key.endsWith("node_modules/inflight")) throw Error("Maintenance regression");
 if(key.endsWith("node_modules/glob") && pkg.version!=="14.0.2") throw Error("Glob regression");
 if(key.endsWith("node_modules/core-js") && pkg.version.startsWith("2.")) throw Error("Core-js regression");
}
NODE
        npm ci --no-audit --strict-peer-deps --engine-strict
        node /reports/probe-tao-remaining.cjs /reports/consumers.after.json /reports/encoding-labels.json
        node -e "require(\"node:assert/strict\").deepEqual(require(\"/reports/consumers.after.json\"),require(\"/reports/consumers.before.json\"))"
        npm run prelint
        audit_status=0
        npm audit --json > /reports/audit-full.json || audit_status=$?
        printf "%s\n" "$audit_status" > /reports/audit-full.exit
        audit_status=0
        npm audit --omit=dev --json > /reports/audit-production.json || audit_status=$?
        printf "%s\n" "$audit_status" > /reports/audit-production.exit
    ' > "$reports/validate.log" 2>&1 || status=$?
cp "$candidate/awx/ui/package.json" "$candidate/awx/ui/package-lock.json" "$reports/"
sha256sum "$candidate/awx/ui/package.json" "$candidate/awx/ui/package-lock.json" > "$reports/ui-inputs.sha256"
printf '%s\n' "$status" > "$reports/exit-code.txt"
tail -n 50 "$reports/validate.log"
printf 'Reports: %s (exit %s)\n' "$reports" "$status"
exit "$status"
