const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const {createRequire} = require('node:module');
const {Readable} = require('node:stream');
(async()=>{
  const fromUI=createRequire(path.join(process.cwd(),'package.json'));
  const get=fromUI('lodash.get'), equal=fromUI('lodash.isequal');
  const fromAce=createRequire(fromUI.resolve('react-ace'));
  const fromEnzyme=createRequire(fromUI.resolve('enzyme'));
  assert.equal(fromAce('lodash.get'),get);
  assert.equal(fromAce('lodash.isequal'),equal);
  assert.equal(fromEnzyme('lodash.isequal'),equal);
  const fromCheerio=createRequire(fromUI.resolve('cheerio'));
  const sniffer=fromCheerio('encoding-sniffer');
  const fromSniffer=createRequire(fromCheerio.resolve('encoding-sniffer'));
  const encoding=fromSniffer('whatwg-encoding');
  const labelFile=process.argv[3];
  if(!fs.existsSync(labelFile)) {
    const original=path.join(path.dirname(fromSniffer.resolve('whatwg-encoding')),'labels-to-names.json');
    fs.writeFileSync(labelFile,JSON.stringify(Object.keys(JSON.parse(fs.readFileSync(original)))));
  }
  const labels=JSON.parse(fs.readFileSync(labelFile));
  const labelResults=[...labels,...labels.map(x=>' \t'+x.toUpperCase()+'\n'),'', 'not-an-encoding',null,123]
    .map(label=>encoding.labelToName(label));
  const object=Object.assign(Object.create({inherited:9}),{a:{b:[{c:3}]},'a.b':7,n:null});
  const getCases=[['a.b',null],['a.b[0].c','missing'],[['a','b',0,'c'],'missing'],['n','default'],
    ['missing','default'],['inherited',0],['a.b[1]',false]];
  const getResults=getCases.map(([key,fallback])=>get(object,key,fallback));
  const c1={value:1},c2={value:1};c1.self=c1;c2.self=c2;
  const symbol=Symbol('key');
  const comparisons=[
    [{a:[1,2]},{a:[1,2]}], [{a:[1,2]},{a:[2,1]}], [NaN,NaN], [-0,0], [null,undefined],
    [new Date(100),new Date(100)],[/a/gi,/a/gi], [new Set([1,2]),new Set([2,1])],
    [new Map([['a',1]]),new Map([['a',1]])],[new Uint8Array([1,2]),new Uint8Array([1,2])],
    [Buffer.from('x'),Buffer.from('x')],[c1,c2],[{[symbol]:1},{[symbol]:1}],
  ];
  const equalResults=comparisons.map(([a,b])=>equal(a,b));
  const documents=[
    Buffer.from('<meta charset="utf-8"><p>Singapore 新加坡</p>'),
    Buffer.from('<meta charset="windows-1252"><p>caf\xe9</p>','latin1'),
    Buffer.concat([Buffer.from([0xef,0xbb,0xbf]),Buffer.from('<p>BOM 中文</p>')]),
    Buffer.concat([Buffer.from([0xff,0xfe]),Buffer.from('<p>UTF16 中文</p>','utf16le')]),
    Buffer.from('<meta charset="invalid"><p>fallback</p>'),
  ];
  const decoded=[],streams=[],cheerio=[];
  for(const buffer of documents) {
    decoded.push(sniffer.decodeBuffer(buffer));
    let text='';
    for await(const chunk of Readable.from([buffer.subarray(0,3),buffer.subarray(3,17),buffer.subarray(17)])
      .pipe(new sniffer.DecodeStream({}))) text+=chunk.toString();
    streams.push(text);
    cheerio.push(fromUI('cheerio').loadBuffer(buffer)('p').text());
  }
  assert.deepEqual(decoded,streams);
  fs.writeFileSync(process.argv[2],JSON.stringify({getResults,equalResults,labelResults,decoded,streams,cheerio},null,2)+'\n');
  console.log('Verified actual Ace/Enzyme dependency resolution,7path cases,13equality cases,',labelResults.length,'labels and5buffer/stream/Cheerio documents');
})().catch(error=>{console.error(error);process.exitCode=1;});
