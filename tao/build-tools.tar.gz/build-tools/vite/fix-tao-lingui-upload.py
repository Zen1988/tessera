"""Remove obsolete Lingui option and await real manifest FileReader completion."""
from pathlib import Path
import json
import re
import sys

if len(sys.argv) != 2:
    raise SystemExit('Usage: python3 fix-tao-lingui-upload.py <TAO checkout>')
ui = Path(sys.argv[1]) / 'awx/ui'
updates = {}
config = ui / '.linguirc'
original = config.read_bytes()
data = json.loads(original)
if 'extractBabelOptions' in data:
    if data['extractBabelOptions'] != {}:
        raise SystemExit('Nonempty obsolete extractor options require review; no writes')
    replacement, count = re.subn(rb'(?m)^[ \t]*"extractBabelOptions"\s*:\s*\{\s*\},[ \t]*\r?\n', b'', original)
    expected = dict(data)
    del expected['extractBabelOptions']
    if count != 1 or json.loads(replacement) != expected:
        raise SystemExit('Unexpected Lingui config; no writes')
    updates[config] = replacement

test = ui / 'src/screens/Setting/Subscription/SubscriptionEdit/SubscriptionStep.test.js'
original = test.read_bytes()
newline = b'\r\n' if b'\r\n' in original else b'\n'
text = original.replace(b'\r\n', b'\n').decode('utf-8')
edits = [
    ("import { mountWithContexts } from '../../../../../testUtils/enzymeHelpers';",
     "import {\n  mountWithContexts,\n  waitForElement,\n} from '../../../../../testUtils/enzymeHelpers';"),
    ("""      wrapper.find('FileUpload').invoke('onChange')(mockFile, 'new file name');
    });
    await act(async () => {
      wrapper.update();
    });
    await act(async () => {
      wrapper.update();
    });""",
     """      wrapper.find('FileUpload').invoke('onChange')(mockFile, 'new file name');
      await waitForElement(
        wrapper,
        'FileUploadField',
        (field) => field.prop('value') === 'MTIz'
      );
    });
    wrapper.update();"""),
    ("""    expect(wrapper.find('FileUploadField').prop('value')).toEqual(
      expect.stringMatching(/^[\\x00-\\x7F]+$/) // eslint-disable-line no-control-regex
    );""",
     "    expect(wrapper.find('FileUploadField').prop('value')).toEqual('MTIz');"),
    ("  afterAll(() => {\n    jest.clearAllMocks();",
     "  afterAll(() => {\n    wrapper.unmount();\n    jest.clearAllMocks();"),
]
for old, new in edits:
    if text.count(old) == 1 and new not in text:
        text = text.replace(old, new)
    elif text.count(old) == 0 and text.count(new) == 1:
        continue
    else:
        raise SystemExit('Unexpected SubscriptionStep test; no writes')
replacement = text.encode('utf-8').replace(b'\n', newline)
if replacement != original:
    updates[test] = replacement
for path, value in updates.items():
    path.write_bytes(value)
    print(f'Updated {path}')
print(f'Updated {len(updates)} files')
