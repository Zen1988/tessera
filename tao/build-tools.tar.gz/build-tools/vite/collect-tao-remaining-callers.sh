#!/usr/bin/env bash
set -euo pipefail
source_dir=$(realpath -e "${1:?Pass the tested popup-clean candidate}")
ui="$source_dir/awx/ui"
test -d "$ui/node_modules/encoding-sniffer"
reports=$(mktemp -d "$PWD/tao-remaining-callers.XXXXXX")
sha256sum "$ui/package.json" "$ui/package-lock.json" > "$reports/ui-inputs.sha256"
podman run --rm -i --pull=never --network=none \
    -v "$ui:/source:ro,Z" -w /source \
    localhost/tessera-awx-application-build:24.6.1-rocky10-maintenance-glob-r1 python - \
    > "$reports/remaining-callers.tar.gz" <<'PY'
from pathlib import Path
import json
import sys
import tarfile

root = Path.cwd()
lock = json.loads((root / 'package-lock.json').read_text())
names = {'cheerio', 'encoding-sniffer', 'whatwg-encoding', '@lingui/conf',
         'react-ace', 'enzyme', 'lodash.get', 'lodash.isequal', 'lodash'}
selected = {root / 'package.json', root / 'package-lock.json', root / '.linguirc',
            root / 'jest.config.cjs', root / 'tao-jest-environment.cjs'}
suffixes = {'.js', '.jsx', '.mjs', '.cjs', '.ts', '.tsx', '.json'}
for name, metadata in lock['packages'].items():
    if not any(name.endswith('node_modules/' + package) for package in names):
        continue
    folder = root / name
    if not folder.is_dir():
        raise SystemExit('Installed dependency missing: ' + name)
    for path in folder.rglob('*'):
        if 'node_modules' in path.relative_to(folder).parts or not path.is_file():
            continue
        if path.suffix in suffixes or path.name.upper().startswith('LICENSE'):
            selected.add(path)
for path in (root / 'src').rglob('*'):
    if path.is_file() and path.suffix in suffixes:
        text = path.read_text(encoding='utf-8', errors='replace')
        if ('react-ace' in text or 'lodash.get' in text or 'lodash.isequal' in text
                or '/CodeEditor/' in path.as_posix() or path.name == 'setupTests.js'):
            selected.add(path)
with tarfile.open(fileobj=sys.stdout.buffer, mode='w|gz') as archive:
    for path in sorted(selected):
        if not path.is_file():
            continue
        if path.is_symlink() or not path.resolve().is_relative_to(root):
            raise SystemExit('Source outside UI')
        archive.add(path, arcname=path.relative_to(root), recursive=False)
print(f'Collected {len(selected)} files', file=sys.stderr)
PY
sha256sum "$reports/remaining-callers.tar.gz" > "$reports/remaining-callers.sha256"
printf 'Send remaining-callers.tar.gz and ui-inputs.sha256 from %s\n' "$reports"
