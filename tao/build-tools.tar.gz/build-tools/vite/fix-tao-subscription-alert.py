"""Use the existing stable success-alert identifier in subscription assertions."""
from pathlib import Path
import sys

if len(sys.argv) != 2:
    raise SystemExit('Usage: python3 fix-tao-subscription-alert.py <TAO checkout>')
path = Path(sys.argv[1]) / 'awx/ui/src/screens/Setting/Subscription/SubscriptionEdit/SubscriptionEdit.test.js'
source = path.read_bytes()
old = b'Alert[title="Save successful"]'
new = b'Alert[ouiaId="success-alert"]'
if source.count(old) == 4 and new not in source:
    path.write_bytes(source.replace(old, new))
    print(f'Updated {path}')
elif old not in source and source.count(new) == 4:
    print('Success alert selectors already updated')
else:
    raise SystemExit('Unexpected success alert selectors; no write')
