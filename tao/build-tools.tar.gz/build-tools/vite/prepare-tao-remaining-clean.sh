#!/usr/bin/env bash
set -euo pipefail
source_dir=$(realpath -e "${1:?Pass tested popup-clean checkout}")
candidate=$(realpath -m "${2:?Pass a NEW combined candidate directory}")
kit_dir=$(cd "$(dirname "$0")" && pwd)
image=localhost/tessera-awx-application-build:24.6.1-rocky10-maintenance-glob-r1
test ! -e "$candidate" || { printf 'Candidate already exists\n' >&2; exit 1; }
case "$candidate/" in "$source_dir/"*) printf 'Candidate must be outside baseline\n' >&2; exit 1 ;; esac
actual=$(sha256sum "$source_dir/awx/ui/package-lock.json")
[[ ${actual%% *} == a5fd73018a0d30c2566cfbdebe4986208b0700c1515f4502e861eec9f9dbf62b ]] || {
    printf 'Source lock differs from tested Popper baseline\n' >&2; exit 1;
}
podman image inspect "$image" >/dev/null
mkdir "$candidate"
tar -C "$source_dir" --exclude=.git --exclude=node_modules --exclude=awx/ui/build --exclude=dist -cf - . |
    tar -xf - -C "$candidate"
reports=$(mktemp -d "$PWD/tao-remaining-candidate.XXXXXX")
cp "$candidate/awx/ui/package.json" "$reports/package.before.json"
cp "$candidate/awx/ui/package-lock.json" "$reports/package-lock.before.json"
cp "$kit_dir/probe-tao-remaining.cjs" "$kit_dir/pack-tao-remaining-compat.cjs" "$reports/"
printf 'Candidate: %s\nReports: %s\n' "$candidate" "$reports"
status=0
podman run --rm --pull=never --userns=keep-id --timeout=900 \
    -e npm_config_cache=/tmp/tao-npm-cache \
    -v "$candidate/awx/ui:/workspace:Z" -v "$reports:/reports:Z" -w /workspace "$image" \
    bash -euo pipefail -c '
        npm ci --no-audit --strict-peer-deps --engine-strict
        node /reports/probe-tao-remaining.cjs /reports/consumers.before.json /reports/encoding-labels.json
        node /reports/pack-tao-remaining-compat.cjs /tmp/tao-remaining-packages /reports/compat-packages.json
        for package in lodash.get lodash.isequal whatwg-encoding; do
            (cd "/tmp/tao-remaining-packages/$package" && npm pack --ignore-scripts --pack-destination /workspace/vendor --json) > "/reports/$package-pack.json"
        done
        node <<\NODE
const fs=require("node:fs");
const p=require("./package.json");
const definitions=require("/reports/compat-packages.json");
for(const d of definitions) {
 if(p.overrides[d.name] || p.dependencies[d.name] || p.devDependencies[d.name]) throw Error("Unexpected existing direct dependency/override: "+d.name);
 const section=d.name==="whatwg-encoding" ? "devDependencies" : "dependencies";
 p[section][d.name]="file:vendor/"+d.name+"-"+d.version+".tgz";
 p.overrides[d.name]="$"+d.name;
}
fs.writeFileSync("package.json",JSON.stringify(p,null,2)+"\n");
NODE
        npm install --package-lock-only --ignore-scripts --no-audit --strict-peer-deps --engine-strict
        node <<\NODE
const fs=require("node:fs");
const before=require("/reports/package-lock.before.json").packages;
const after=require("./package-lock.json").packages;
const versions={"lodash.get":"4.4.2-tessera.1","lodash.isequal":"4.5.0-tessera.1","whatwg-encoding":"3.1.1-tessera.1"};
const changes=Object.keys({...before,...after}).filter(k=>before[k]?.version!==after[k]?.version)
 .map(k=>({path:k,before:before[k]?.version,after:after[k]?.version}));
fs.writeFileSync("/reports/lock-changes.json",JSON.stringify(changes,null,2));
for(const c of changes) if(!Object.keys(versions).some(n=>c.path.endsWith("node_modules/"+n))) throw Error("Unrelated dependency version change: "+c.path);
for(const [key,pkg] of Object.entries(after)) {
 for(const [name,version] of Object.entries(versions)) if(key.endsWith("node_modules/"+name)) {
   if(pkg.version!==version || !pkg.resolved?.startsWith("file:vendor/") || pkg.deprecated) throw Error("Deprecated registry implementation remains: "+key);
 }
 if(key.endsWith("node_modules/popper.js") || key.endsWith("node_modules/tippy.js") || key.endsWith("node_modules/inflight")) throw Error("Removed dependency reintroduced");
 if(key.endsWith("node_modules/glob") && pkg.version!=="14.0.2") throw Error("Glob regression");
 if(key.endsWith("node_modules/core-js") && pkg.version.startsWith("2.")) throw Error("Core-js regression");
 if(pkg.deprecated) throw Error("Deprecated package remains: "+key);
}
NODE
        npm ci --no-audit --strict-peer-deps --engine-strict
        node /reports/probe-tao-remaining.cjs /reports/consumers.after.json /reports/encoding-labels.json
        node -e "require(\"node:assert/strict\").deepEqual(require(\"/reports/consumers.after.json\"),require(\"/reports/consumers.before.json\"))"
        npm run prelint
        audit_status=0
        npm audit --json > /reports/audit-full.json || audit_status=$?
        printf "%s\n" "$audit_status" > /reports/audit-full.exit
        audit_status=0
        npm audit --omit=dev --json > /reports/audit-production.json || audit_status=$?
        printf "%s\n" "$audit_status" > /reports/audit-production.exit
    ' > "$reports/prepare.log" 2>&1 || status=$?
cp "$candidate/awx/ui/package.json" "$candidate/awx/ui/package-lock.json" "$reports/"
sha256sum "$candidate/awx/ui/package.json" "$candidate/awx/ui/package-lock.json" > "$reports/ui-inputs.sha256"
printf '%s\n' "$status" > "$reports/exit-code.txt"
tail -n 50 "$reports/prepare.log"
printf 'Candidate: %s\nReports: %s (exit %s)\n' "$candidate" "$reports" "$status"
exit "$status"
