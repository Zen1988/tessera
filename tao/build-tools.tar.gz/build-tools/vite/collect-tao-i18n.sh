#!/usr/bin/env bash
set -euo pipefail
image=localhost/tessera-awx-application-build:24.6.1-rocky10-maintenance-final-r1
reports=$(mktemp -d "$PWD/tao-i18n.XXXXXX")
printf 'Reports: %s\n' "$reports"
podman image inspect --format '{{.Id}}' "$image" > "$reports/image-id.txt"
podman run --rm --pull=never --network=none --read-only --entrypoint /bin/bash \
  -w /build/awx/awx/ui "$image" -ec '
paths=()
for p in package.json vite.config.mjs babel.config.* .babelrc* .lingui* lingui.config.* src/i18n* src/locales src/screens/Login src/components/Login; do
  [[ ! -e "$p" ]] || paths+=("$p")
done
tar -czf - "${paths[@]}"
' > "$reports/catalog-source.tar.gz"
tar -czf "$PWD/tao-i18n-reports.tar.gz" -C "$reports" .
printf 'Send %s/tao-i18n-reports.tar.gz\n' "$PWD"
