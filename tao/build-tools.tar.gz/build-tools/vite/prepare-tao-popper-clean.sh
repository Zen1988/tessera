#!/usr/bin/env bash
set -euo pipefail
source_dir=$(realpath -e "${1:?Pass the verified glob checkout}")
candidate=$(realpath -m "${2:?Pass a NEW popup-clean candidate directory}")
kit_dir=$(cd "$(dirname "$0")" && pwd)
image=localhost/tessera-awx-application-build:24.6.1-rocky10-maintenance-glob-r1
test ! -e "$candidate" || { printf 'Candidate already exists\n' >&2; exit 1; }
case "$candidate/" in "$source_dir/"*) printf 'Candidate must be outside baseline\n' >&2; exit 1 ;; esac
actual=$(sha256sum "$source_dir/awx/ui/package-lock.json")
[[ ${actual%% *} == f655c651fb729aed8ce5bed5f60e49cf78fade120456abdc0bea9f5fc8f610f9 ]] || {
    printf 'Source lock differs from verified glob baseline\n' >&2; exit 1;
}
podman image inspect "$image" >/dev/null
mkdir "$candidate"
tar -C "$source_dir" --exclude=.git --exclude=node_modules --exclude=awx/ui/build --exclude=dist -cf - . |
    tar -xf - -C "$candidate"
reports=$(mktemp -d "$PWD/tao-popper-candidate.XXXXXX")
cp "$candidate/awx/ui/package.json" "$reports/package.before.json"
cp "$candidate/awx/ui/package-lock.json" "$reports/package-lock.before.json"
cp "$kit_dir/probe-tao-popper.cjs" "$reports/"
printf 'Candidate: %s\nReports: %s\n' "$candidate" "$reports"
status=0
podman run --rm --pull=never --userns=keep-id --timeout=900 \
    -e npm_config_cache=/tmp/tao-npm-cache \
    -v "$candidate/awx/ui:/workspace:Z" -v "$reports:/reports:Z" -w /workspace "$image" \
    bash -euo pipefail -c '
        npm ci --no-audit --strict-peer-deps --engine-strict
        node /reports/probe-tao-popper.cjs /reports/patternfly.before.json
        cp -a node_modules/@patternfly/react-core /tmp/tao-core-no-tippy
        node <<\NODE
const fs = require("node:fs");
const file = "/tmp/tao-core-no-tippy/package.json";
const p = JSON.parse(fs.readFileSync(file));
if(p.version!=="4.276.8" || p.dependencies["tippy.js"]!=="5.1.2") throw Error("Unexpected PatternFly manifest");
delete p.dependencies["tippy.js"];
// Keep the public version compatible with react-table; tarball spec/integrity and
// explicit revision identify this manifest-only TESSERA distribution.
p.tesseraPackageRevision = "remove-unused-tippy.1";
fs.writeFileSync(file,JSON.stringify(p,null,2)+"\n");
fs.writeFileSync("/reports/patternfly-manifest-patch.json",JSON.stringify({upstream:"@patternfly/react-core@4.276.8",revision:p.tesseraPackageRevision,removedDependency:"tippy.js@5.1.2",runtimeFilesChanged:0},null,2));
NODE
        mkdir -p vendor
        test ! -e vendor/patternfly-react-core-4.276.8-no-tippy.1.tgz
        (cd /tmp/tao-core-no-tippy && npm pack --ignore-scripts --pack-destination /workspace/vendor --json) > /reports/patternfly-pack.json
        mv vendor/patternfly-react-core-4.276.8.tgz vendor/patternfly-react-core-4.276.8-no-tippy.1.tgz
        node <<\NODE
const fs = require("node:fs");
const p = require("./package.json");
if(p.dependencies["@patternfly/react-core"]!=="4.276.8" || p.overrides["@patternfly/react-core"]) throw Error("Unexpected core dependency/override");
p.dependencies["@patternfly/react-core"] = "file:vendor/patternfly-react-core-4.276.8-no-tippy.1.tgz";
p.overrides["@patternfly/react-core"] = "$@patternfly/react-core";
fs.writeFileSync("package.json",JSON.stringify(p,null,2)+"\n");
NODE
        npm install --package-lock-only --ignore-scripts --no-audit --strict-peer-deps --engine-strict
        node <<\NODE
const fs = require("node:fs");
const before = require("/reports/package-lock.before.json").packages;
const after = require("./package-lock.json").packages;
const changes = Object.keys({...before,...after}).filter(k=>JSON.stringify(before[k])!==JSON.stringify(after[k]))
 .map(k=>({path:k,before:before[k]?.version,after:after[k]?.version}));
fs.writeFileSync("/reports/lock-changes.json",JSON.stringify(changes,null,2));
for(const [k,v] of Object.entries(after)) {
 if(k.endsWith("node_modules/tippy.js") || k.endsWith("node_modules/popper.js")) throw Error("Legacy popup dependency remains: "+k);
 if(k.endsWith("node_modules/@patternfly/react-core") && !v.resolved?.includes("no-tippy.1.tgz")) throw Error("Unpatched core copy: "+k);
 if(k.endsWith("node_modules/glob") && v.version!=="14.0.2") throw Error("Glob regression");
 if(k.endsWith("node_modules/inflight") || (k.endsWith("node_modules/core-js") && v.version.startsWith("2."))) throw Error("Maintenance regression");
}
NODE
        npm ci --no-audit --strict-peer-deps --engine-strict
        node /reports/probe-tao-popper.cjs /reports/patternfly.after.json
        node -e "require(\"node:assert/strict\").deepEqual(require(\"/reports/patternfly.after.json\"),require(\"/reports/patternfly.before.json\"))"
        audit_status=0
        npm audit --json > /reports/audit-full.json || audit_status=$?
        printf "%s\n" "$audit_status" > /reports/audit-full.exit
        audit_status=0
        npm audit --omit=dev --json > /reports/audit-production.json || audit_status=$?
        printf "%s\n" "$audit_status" > /reports/audit-production.exit
    ' > "$reports/prepare.log" 2>&1 || status=$?
cp "$candidate/awx/ui/package.json" "$candidate/awx/ui/package-lock.json" "$reports/"
sha256sum "$candidate/awx/ui/package.json" "$candidate/awx/ui/package-lock.json" > "$reports/ui-inputs.sha256"
printf '%s\n' "$status" > "$reports/exit-code.txt"
tail -n 45 "$reports/prepare.log"
printf 'Candidate: %s\nReports: %s (exit %s)\n' "$candidate" "$reports" "$status"
exit "$status"
