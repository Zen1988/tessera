"""Collect tracked UI source for reviewing the remaining PropTypes lint errors."""
from pathlib import Path
import hashlib
import re
import subprocess
import sys
import tarfile


def main():
    if len(sys.argv) != 3:
        raise SystemExit("Usage: python3 collect-tao-proptypes.py <TAO checkout> <output.tar.gz>")
    checkout = Path(sys.argv[1]).resolve()
    ui = checkout / "awx/ui"
    output = Path(sys.argv[2]).resolve()
    targets = (
        "components/AdHocCommands/AdHocCommands.js",
        "components/AdHocCommands/AdHocCommandsWizard.js",
        "components/AdHocCommands/AdHocDetailsStep.js",
        "components/AddRole/SelectResourceStep.js",
        "components/AddRole/SelectRoleStep.js",
        "components/AppContainer/NavExpandableGroup.js",
        "components/SelectedList/SelectedList.js",
        "screens/Application/shared/ApplicationForm.js",
        "screens/Inventory/InventoryEdit/InventoryEdit.js",
    )
    selected = {"awx/ui/src/" + name for name in targets}
    for name in selected:
        if not (checkout / name).is_file():
            raise SystemExit(f"Missing expected source: {name}")
    names = re.compile(r"\b(?:" + "|".join(Path(p).stem for p in targets) + r")\b")
    tracked = subprocess.check_output(
        ["git", "-C", str(checkout), "ls-files", "-z", "--", "awx/ui/src", "awx/ui/testUtils"],
    ).decode().split("\0")
    for name in tracked:
        path = checkout / name
        if path.suffix in (".js", ".jsx") and path.is_file():
            if names.search(path.read_text(encoding="utf-8")) or "/types/" in name:
                selected.add(name)
    for name in ("package.json", "package-lock.json", "eslint.config.cjs", "tao-eslint-policy.json"):
        path = ui / name
        if path.is_file():
            print(f"{hashlib.sha256(path.read_bytes()).hexdigest()}  awx/ui/{name}")
    # Exclusive creation prevents replacement of an existing report.
    with output.open("xb") as stream:
        with tarfile.open(fileobj=stream, mode="w:gz") as archive:
            for name in sorted(selected):
                path = checkout / name
                if path.is_symlink() or not path.resolve().is_relative_to(checkout):
                    raise SystemExit(f"Refusing source outside checkout: {name}")
                archive.add(path, arcname=name, recursive=False)
    print(f"Collected {len(selected)} source files in {output}")


if __name__ == "__main__":
    main()
