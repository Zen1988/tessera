const environment = require('@jest/environment-jsdom-abstract');
const jsdom = require('jsdom');
const BaseEnvironment = environment.default ?? environment;

module.exports = class TaoJestEnvironment extends BaseEnvironment {
  constructor(config, context) {
    super(config, context, jsdom);
    // Dependency loading precedes setupTests and snapshot serializers.
    const nativeGlobals = {
      ...require('node:stream/web'),
      TextEncoder: require('node:util').TextEncoder,
      TextDecoder: require('node:util').TextDecoder,
      MessagePort: require('node:worker_threads').MessagePort,
    };
    for (const [name, value] of Object.entries(nativeGlobals)) {
      if (this.global[name] === undefined) {
        Object.defineProperty(this.global, name, {
          configurable: true,
          writable: true,
          value,
        });
      }
    }
  }
};
