"""Preserve native Location and test login navigation through a small adapter."""
from pathlib import Path
import sys

if len(sys.argv) != 2:
    raise SystemExit('Usage: python3 fix-tao-app-redirect.py <TAO checkout>')
src = Path(sys.argv[1]) / 'awx/ui/src'
helper = src / 'util/loginRedirect.js'
contents = b'''export default function replaceLoginLocation(url) {
  window.location.replace(url);
}
'''
if helper.exists() and helper.read_bytes().replace(b'\r\n', b'\n') != contents:
    raise SystemExit('Existing loginRedirect helper differs; no writes')
edits = {
    'App.js': [
        ("import { isAuthenticated } from 'util/auth';",
         "import { isAuthenticated } from 'util/auth';\nimport replaceLoginLocation from 'util/loginRedirect';"),
        ('    window.location.replace(loginRedirectOverride);',
         '    replaceLoginLocation(loginRedirectOverride);'),
    ],
    'App.test.js': [
        ("import { shallow } from 'enzyme';",
         "import { shallow } from 'enzyme';\nimport replaceLoginLocation from 'util/loginRedirect';"),
        ("jest.mock('./api');", "jest.mock('./api');\njest.mock('util/loginRedirect', () => jest.fn());"),
        ("""    const { location } = window;
    delete window.location;
    window.location = {
      replace: jest.fn(),
      href: '/',
    };

    expect(window.location.replace).not.toHaveBeenCalled();""",
         '    expect(replaceLoginLocation).not.toHaveBeenCalled();'),
        ("""    await act(async () => {
      mountWithContexts(
        <ProtectedRoute>""", """    let wrapper;
    await act(async () => {
      wrapper = mountWithContexts(
        <ProtectedRoute>"""),
        ("""    expect(window.location.replace).toHaveBeenCalled();
    window.location = location;""", """    expect(replaceLoginLocation).toHaveBeenCalledWith('/sso/test');
    wrapper.unmount();"""),
    ],
}
updates = {}
for name, replacements in edits.items():
    path = src / name
    original = path.read_bytes()
    newline = b'\r\n' if b'\r\n' in original else b'\n'
    text = original.replace(b'\r\n', b'\n').decode('utf-8')
    for old, new in replacements:
        if text.count(new) == 1:
            continue
        elif text.count(old) == 1 and new not in text:
            text = text.replace(old, new)
        else:
            raise SystemExit(f'Unexpected source {path}; no writes')
    updated = text.encode('utf-8').replace(b'\n', newline)
    if updated != original:
        updates[path] = updated
if not helper.exists():
    updates[helper] = contents
for path, data in updates.items():
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    print(f'Updated {path}')
print(f'Updated {len(updates)} files')
