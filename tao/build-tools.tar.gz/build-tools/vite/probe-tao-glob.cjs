const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const assert = require('node:assert/strict');
const { createRequire } = require('node:module');

(async () => {
  const fromUI = createRequire(path.join(process.argv[3] || process.cwd(), 'package.json'));
  const cliRoot = path.resolve(path.dirname(fromUI.resolve('@lingui/cli/api')), '../..');
  const fromLoader = createRequire(fromUI.resolve('@lingui/loader'));
  assert.equal(fromLoader.resolve('@lingui/cli/api'), fromUI.resolve('@lingui/cli/api'),
    'Loader and UI must resolve the same CLI package');
  const fromCLI = createRequire(path.join(cliRoot, 'package.json'));
  const fromVite = createRequire(fromUI.resolve('vite'));
  assert.equal(fromCLI('esbuild/package.json').version, '0.25.0');
  assert.equal(fromVite('esbuild/package.json').version, '0.28.2');
  const { Catalog } = fromUI(path.join(cliRoot, 'dist/api/catalog.js'));
  const { getCatalogs } = fromUI(path.join(cliRoot, 'dist/api/catalog/getCatalogs.js'));
  const { getEntryPoints } = fromUI(path.join(cliRoot, 'dist/extract-experimental/getEntryPoints.js'));
  const { getFormat } = fromUI(path.join(cliRoot, 'dist/api/formats/index.js'));
  const format = await getFormat('po', {}, 'en');
  const fromIstanbul = createRequire(fromUI.resolve('babel-plugin-istanbul'));
  const TestExclude = fromIstanbul('test-exclude');
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tao-glob-probe-'));
  try {
    for (const name of ['src/app.js', 'src/view.jsx', 'src/app.test.js', 'src/.hidden.js',
      'src/ignored/skip.js', 'src/locales/en/messages.js', 'named/one/index.js', 'named/two/index.js']) {
      const file = path.join(root, name);
      fs.mkdirSync(path.dirname(file), { recursive: true });
      fs.writeFileSync(file, 'const answer = 42;');
    }
    const normalize = values => values.map(value => value.replaceAll(root, '<fixture>')).sort();
    const catalog = new Catalog({name:'probe', path: root + '/src/locales/{locale}/messages',
      include:[root + '/src'], exclude:['**/ignored/**'], format}, {locales:['en']});
    const coverage = new TestExclude({cwd:root, include:['src/**'],
      exclude:['**/*.test.js', '**/ignored/**'], extension:['.js','.jsx']});
    const actualCatalog = new Catalog({name:'actual',
      path:process.cwd()+'/src/locales/{locale}/messages',
      include:[process.cwd()+'/src'], exclude:['**/node_modules/**'],format}, {locales:['en']});
    const named = await getCatalogs({format:'po', formatOptions:{}, sourceLocale:'en', locales:['en'],
      catalogs:[{path:root + '/locales/{name}/{locale}/messages', include:[root + '/named/{name}']}]});
    const result = {
      sourcePaths: normalize(catalog.sourcePaths),
      actualSourcePaths: actualCatalog.sourcePaths.sort(),
      entryPoints: normalize(getEntryPoints([root + '/src/*.js', root + '/src/*.jsx'])),
      namedCatalogs: named.map(c => c.name).sort(),
      coverageSync: coverage.globSync(root).sort(),
      coverageAsync: (await coverage.glob(root)).sort(),
    };
    assert.deepEqual(result.coverageSync, result.coverageAsync);
    assert(result.sourcePaths.some(name => name.endsWith('/app.js')));
    assert(!result.sourcePaths.some(name => name.includes('/ignored/')));
    assert.deepEqual(result.namedCatalogs, ['one', 'two']);
    const code = fromUI('@babel/core').transformSync('const answer = 42;', {
      filename:path.join(root,'src/app.js'), babelrc:false, configFile:false,
      plugins:[[fromUI.resolve('babel-plugin-istanbul'), {
        cwd:root, include:['src/**'], exclude:['**/*.test.js'],
      }]],
    }).code;
    assert(code.includes('__coverage__'), 'Actual Babel coverage instrumentation missing');
    fs.writeFileSync(process.argv[2], JSON.stringify(result, null, 2) + '\n');
    console.log('Verified catalog source discovery, named catalogs, entrypoints, sync/async coverage and Babel instrumentation');
  } finally {
    fs.rmSync(root, {recursive:true, force:true});
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
