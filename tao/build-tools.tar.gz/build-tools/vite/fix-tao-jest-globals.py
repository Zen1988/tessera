"""Add native Node globals before Enzyme/Undici serializer loading."""
from pathlib import Path
import sys

if len(sys.argv) != 2:
    raise SystemExit('Usage: python3 fix-tao-jest-globals.py <TAO checkout>')
path = Path(sys.argv[1]) / 'awx/ui/tao-jest-environment.cjs'
template = Path(__file__).with_name('tao-jest-environment.cjs').read_bytes()
anchor = b'    super(config, context, jsdom);'
insertion = template.split(anchor, 1)[1].split(b'\n  }', 1)[0]
original = path.read_bytes()
newline = b'\r\n' if b'\r\n' in original else b'\n'
source = original.replace(b'\r\n', b'\n')
if anchor + insertion in source:
    print('Native Jest globals already configured')
elif source.count(anchor) != 1 or b'nativeGlobals' in source:
    raise SystemExit('Unexpected environment source; no write')
else:
    path.write_bytes(source.replace(anchor, anchor + insertion).replace(b'\n', newline))
    print(f'Updated {path}')
