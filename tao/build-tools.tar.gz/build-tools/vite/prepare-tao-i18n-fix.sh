#!/usr/bin/env bash
set -euo pipefail
source_dir=$(realpath "${1:?Pass the verified final source checkout}")
candidate=$(realpath -m "${2:?Pass a NEW candidate directory}")
kit=$(cd -- "$(dirname -- "$0")" && pwd)
[[ ! -e "$candidate" ]] || { echo 'Candidate already exists; choose a new directory' >&2; exit 2; }
test -f "$source_dir/awx/ui/.linguirc"
mkdir -p "$candidate"
tar -C "$source_dir" --exclude='./awx/ui/node_modules' --exclude='./awx/ui/build' -cf - . | tar -C "$candidate" -xf -
python3 - "$candidate/awx/ui/.linguirc" <<'PY'
import json, sys
from pathlib import Path
p = Path(sys.argv[1])
config = json.loads(p.read_text())
assert config['compileNamespace'] == 'cjs', 'Unexpected catalog namespace'
config['compileNamespace'] = 'es'
p.write_text(json.dumps(config, indent=2) + '\n')
loader = p.parent / 'src/i18nLoader.js'
s = loader.read_text()
old = './locales/${locale}/messages`'
assert s.count(old) == 1
loader.write_text(s.replace(old, './locales/${locale}/messages.mjs`'))
PY
cp "$kit/probe-tao-i18n.mjs" "$candidate/awx/ui/"
reports=$(mktemp -d "$PWD/tao-i18n-candidate.XXXXXX")
printf 'Candidate: %s\nReports: %s\n' "$candidate" "$reports"
podman run --rm --pull=never --userns=keep-id \
  -e npm_config_cache=/tmp/tao-npm-cache \
  -v "$candidate/awx/ui:/workspace:Z" -w /workspace \
  localhost/tessera-awx-application-build:24.6.1-rocky10-maintenance-final-r1 \
  bash -ec 'npm ci --no-audit; npm run prelint; NODE_ENV=production node probe-tao-i18n.mjs; npm run build' \
  2>&1 | tee "$reports/prepare.log"
sha256sum "$candidate/awx/ui/package.json" "$candidate/awx/ui/package-lock.json" "$candidate/awx/ui/.linguirc" > "$reports/ui-inputs.sha256"
printf 'Production translation probe and complete UI build passed. Reports: %s\n' "$reports"
