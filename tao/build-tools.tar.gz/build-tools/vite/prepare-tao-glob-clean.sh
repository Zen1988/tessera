#!/usr/bin/env bash
set -euo pipefail
source_dir=$(realpath -e "${1:?Pass the verified core-js checkout}")
candidate=$(realpath -m "${2:?Pass a new glob candidate directory}")
kit_dir=$(cd "$(dirname "$0")" && pwd)
image=localhost/tessera-awx-application-build:24.6.1-rocky10-eslint10-r3
test ! -e "$candidate" || { printf 'Candidate already exists\n' >&2; exit 1; }
case "$candidate/" in "$source_dir/"*) printf 'Candidate must be outside baseline\n' >&2; exit 1 ;; esac
actual=$(sha256sum "$source_dir/awx/ui/package-lock.json")
[[ ${actual%% *} == 50eabebc0e10a0ab6ed9fe7a6927a36b6bff89f2c7912a07175b15065bc97048 ]] || {
    printf 'Source lock differs from tested core-js baseline\n' >&2; exit 1;
}
podman image inspect "$image" >/dev/null
mkdir "$candidate"
tar -C "$source_dir" --exclude=.git --exclude=node_modules --exclude=awx/ui/build --exclude=dist -cf - . |
    tar -xf - -C "$candidate"
reports=$(mktemp -d "$PWD/tao-glob-candidate.XXXXXX")
printf 'Candidate: %s\nReports: %s\n' "$candidate" "$reports"
cp "$candidate/awx/ui/package.json" "$reports/package.before.json"
cp "$candidate/awx/ui/package-lock.json" "$reports/package-lock.before.json"
cp "$kit_dir/probe-tao-glob.cjs" "$kit_dir/patch-tao-lingui-glob.cjs" "$reports/"
status=0
podman run --rm --pull=never --userns=keep-id --timeout=900 \
    -e npm_config_cache=/tmp/tao-npm-cache \
    -v "$candidate/awx/ui:/workspace:Z" -v "$reports:/reports:Z" -w /workspace "$image" \
    bash -euo pipefail -c '
        npm view test-exclude@8.0.0 version engines dependencies --json > /reports/test-exclude-metadata.json
        npm ci --no-audit --strict-peer-deps --engine-strict
        npm run prelint
        node /reports/probe-tao-glob.cjs /reports/consumers.before.json
        cp -a node_modules/@lingui/cli /tmp/tao-cli-glob14
        node /reports/patch-tao-lingui-glob.cjs /tmp/tao-cli-glob14 /reports/lingui-patch.json
        mkdir -p vendor
        test ! -e vendor/lingui-cli-4.14.1-tessera.1.tgz
        (cd /tmp/tao-cli-glob14 && npm pack --ignore-scripts --pack-destination /workspace/vendor --json) > /reports/lingui-pack.json
        packed=$(node -p "JSON.parse(require(\"node:fs\").readFileSync(\"/reports/lingui-pack.json\"))[0].filename")
        if [[ "$packed" != lingui-cli-4.14.1-tessera.1.tgz ]]; then
            mv "vendor/$packed" vendor/lingui-cli-4.14.1-tessera.1.tgz
        fi
        node <<\NODE
const fs = require("node:fs");
const p = require("./package.json");
if(p.devDependencies["@lingui/cli"] !== "4.14.1") throw Error("Unexpected Lingui baseline");
if(JSON.stringify(p.overrides["@lingui/cli"]) !== JSON.stringify({esbuild:"0.25.0"})) throw Error("Unexpected Lingui override");
p.devDependencies["@lingui/cli"] = "file:vendor/lingui-cli-4.14.1-tessera.1.tgz";
p.overrides["@lingui/cli"] = "$@lingui/cli";
delete p.overrides["glob@7.1.7"];
if(p.overrides["babel-plugin-istanbul"] || p.overrides["test-exclude@8.0.0"]) throw Error("Existing coverage override");
p.overrides["babel-plugin-istanbul"] = {
  "test-exclude": {".":"8.0.0",glob:"14.0.2",minimatch:"11.0.1"}
};
fs.writeFileSync("package.json",JSON.stringify(p,null,2)+"\n");
NODE
        npm install --package-lock-only --ignore-scripts --no-audit --strict-peer-deps --engine-strict
        node <<\NODE
const fs = require("node:fs");
const before = require("/reports/package-lock.before.json").packages;
const after = require("./package-lock.json").packages;
const changes = Object.keys({...before,...after}).filter(k => before[k]?.version !== after[k]?.version)
 .map(k=>({path:k,before:before[k]?.version,after:after[k]?.version}));
fs.writeFileSync("/reports/lock-changes.json",JSON.stringify(changes,null,2));
for(const [name,p] of Object.entries(after)) {
 if(name.endsWith("node_modules/inflight")) throw Error("inflight remains");
 if(name.endsWith("node_modules/glob") && p.version !== "14.0.2") throw Error("Unexpected glob version: "+p.version);
 if(name.endsWith("node_modules/core-js") && p.version.startsWith("2.")) throw Error("core-js2 reintroduced");
 if(name.endsWith("node_modules/@lingui/cli") && p.version !== "4.14.1-tessera.1") throw Error("Unpatched nested Lingui CLI: "+name);
 if(name.endsWith("node_modules/esbuild") && !["0.25.0","0.28.2"].includes(p.version)) throw Error("Unexpected esbuild version: "+p.version);
}
NODE
        npm ci --no-audit --strict-peer-deps --engine-strict
        node /reports/probe-tao-glob.cjs /reports/consumers.after.json
        node -e "require(\"node:assert/strict\").deepEqual(require(\"/reports/consumers.after.json\"),require(\"/reports/consumers.before.json\"))"
        npm run prelint
        audit_status=0
        npm audit --json > /reports/audit-full.json || audit_status=$?
        printf "%s\n" "$audit_status" > /reports/audit-full.exit
        audit_status=0
        npm audit --omit=dev --json > /reports/audit-production.json || audit_status=$?
        printf "%s\n" "$audit_status" > /reports/audit-production.exit
    ' > "$reports/prepare.log" 2>&1 || status=$?
cp "$candidate/awx/ui/package.json" "$reports/package.json"
cp "$candidate/awx/ui/package-lock.json" "$reports/package-lock.json"
sha256sum "$candidate/awx/ui/package.json" "$candidate/awx/ui/package-lock.json" > "$reports/ui-inputs.sha256"
printf '%s\n' "$status" > "$reports/exit-code.txt"
tail -n 50 "$reports/prepare.log"
printf 'Candidate: %s\nReports: %s (exit %s)\n' "$candidate" "$reports" "$status"
exit "$status"
