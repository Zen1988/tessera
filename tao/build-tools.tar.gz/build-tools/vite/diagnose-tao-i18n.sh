#!/usr/bin/env bash
set -euo pipefail
source_dir=$(realpath "${1:?Pass the existing i18n candidate}")
kit=$(cd -- "$(dirname -- "$0")" && pwd)
cp "$kit/probe-tao-i18n.mjs" "$source_dir/awx/ui/"
reports=$(mktemp -d "$PWD/tao-i18n-diagnostics.XXXXXX")
mkdir -p "$reports/bundle"
chmod 755 "$reports/bundle"
printf 'Reports: %s\n' "$reports"
status=0
podman run --rm --pull=never --userns=keep-id \
  -v "$source_dir/awx/ui:/workspace:Z" -v "$reports:/reports:Z" -w /workspace \
  -e NODE_ENV=production -e TAO_I18N_DIAGNOSTICS=/reports/bundle \
  localhost/tessera-awx-application-build:24.6.1-rocky10-maintenance-final-r1 \
  node probe-tao-i18n.mjs 2>&1 | tee "$reports/probe.log" || status=$?
printf '%s\n' "$status" > "$reports/exit-code.txt"
cp "$source_dir/awx/ui/.linguirc" "$reports/lingui-config.json"
cp "$source_dir/awx/ui/src/locales/en/messages.mjs" "$reports/english-messages.mjs"
tar -czf "$PWD/tao-i18n-diagnostics.tar.gz" -C "$reports" .
printf 'Probe exit: %s\nSend %s/tao-i18n-diagnostics.tar.gz\n' "$status" "$PWD"
