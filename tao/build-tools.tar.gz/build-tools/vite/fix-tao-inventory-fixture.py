"""Complete the Inventory API fixture with an empty labels summary when absent."""
from pathlib import Path
import sys

if len(sys.argv) != 2:
    raise SystemExit('Usage: python3 fix-tao-inventory-fixture.py <TAO checkout>')
path = Path(sys.argv[1]) / 'awx/ui/src/screens/Inventory/Inventory.test.js'
original = path.read_bytes()
newline = b'\r\n' if b'\r\n' in original else b'\n'
text = original.replace(b'\r\n', b'\n').decode('utf-8')
old = '      data: mockInventory,'
new = '''      data: {
        ...mockInventory,
        summary_fields: {
          ...mockInventory.summary_fields,
          labels: mockInventory.summary_fields.labels || { results: [] },
        },
      },'''
if text.count(new) == 1:
    print('Inventory fixture already completed')
elif text.count(old) == 1:
    path.write_bytes(text.replace(old, new).encode('utf-8').replace(b'\n', newline))
    print(f'Updated {path}')
else:
    raise SystemExit('Unexpected Inventory test API fixture; no write')
