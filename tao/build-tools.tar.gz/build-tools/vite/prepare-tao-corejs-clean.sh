#!/usr/bin/env bash
set -euo pipefail
source_dir=$(realpath -e "${1:?Pass the tested AWX checkout}")
candidate=$(realpath -m "${2:?Pass a new candidate directory}")
image=localhost/tessera-awx-application-build:24.6.1-rocky10-eslint10-r3
test ! -e "$candidate" || { printf 'Candidate already exists: %s\n' "$candidate" >&2; exit 1; }
case "$candidate/" in "$source_dir/"*) printf 'Candidate must be outside source checkout\n' >&2; exit 1 ;; esac
test -f "$source_dir/awx/ui/package-lock.json"
expected_lock=6393786e2a9c0c3140c79d18cfc58bd77ef68410cb1df6373bcc78e7b9e8a1e9
actual_lock=$(sha256sum "$source_dir/awx/ui/package-lock.json")
[[ ${actual_lock%% *} == "$expected_lock" ]] || { printf 'Source lock differs from verified baseline\n' >&2; exit 1; }
podman image inspect "$image" >/dev/null
mkdir "$candidate"
tar -C "$source_dir" --exclude=.git --exclude=node_modules --exclude=awx/ui/build --exclude=dist -cf - . |
    tar -xf - -C "$candidate"
reports=$(mktemp -d "$PWD/tao-corejs-candidate.XXXXXX")
printf 'Candidate: %s\nReports: %s\n' "$candidate" "$reports"
cp "$candidate/awx/ui/package.json" "$reports/package.before.json"
cp "$candidate/awx/ui/package-lock.json" "$reports/package-lock.before.json"
status=0
podman run --rm --pull=never --userns=keep-id --timeout=600 \
    -e npm_config_cache=/tmp/tao-npm-cache \
    -v "$candidate/awx/ui:/workspace:Z" -v "$reports:/reports:Z" \
    -w /workspace "$image" bash -euo pipefail -c '
        npm view attr-accept@4.0.1 version engines exports dependencies --json > /reports/attr-accept-metadata.json
        node <<\NODE
const fs = require("node:fs");
const p = require("./package.json");
if (p.dependencies["@patternfly/react-core"] !== "4.276.8") throw Error("Unexpected PatternFly baseline");
const lock = require("./package-lock.json");
if (lock.packages["node_modules/react-dropzone"]?.version !== "9.0.0") throw Error("Unexpected Dropzone baseline");
p.overrides ??= {};
const key = "react-dropzone@9.0.0";
if (p.overrides[key]) throw Error("Existing scoped override requires review");
p.overrides[key] = { "attr-accept": "4.0.1" };
fs.writeFileSync("package.json", JSON.stringify(p, null, 2) + "\n");
NODE
        npm install --package-lock-only --ignore-scripts --no-audit --strict-peer-deps --engine-strict
        node <<\NODE
const fs = require("node:fs");
const before = require("/reports/package-lock.before.json").packages;
const after = require("./package-lock.json").packages;
const changes = Object.keys({...before, ...after}).filter(k =>
  before[k]?.version !== after[k]?.version).map(k => ({path:k, before:before[k]?.version, after:after[k]?.version}));
fs.writeFileSync("/reports/lock-changes.json", JSON.stringify(changes, null, 2));
for (const change of changes) {
  if (!/node_modules\/(attr-accept|core-js)$/.test(change.path)) throw Error("Unrelated lock change: " + change.path);
}
for (const [key, pkg] of Object.entries(after)) {
  if (key.endsWith("node_modules/core-js") && pkg.version.startsWith("2.")) throw Error("core-js2 remains");
}
NODE
        npm ci --no-audit --strict-peer-deps --engine-strict
        node <<\NODE
const assert = require("node:assert/strict");
const {createRequire} = require("node:module");
const fromDropzone = createRequire(require.resolve("react-dropzone"));
const entry = fromDropzone.resolve("attr-accept");
const imported = fromDropzone("attr-accept");
// Reproduce the default-import convention used by legacy Dropzone Babel output.
const accepts = imported && imported.__esModule ? imported.default : imported;
assert.equal(typeof accepts, "function", "Dropzone default import must stay callable");
const cases = [
  [{name:"manifest.zip",type:"application/zip"}, ".zip", true],
  [{name:"manifest.ZIP",type:""}, ".zip", true],
  [{name:"script.exe",type:"application/octet-stream"}, ".zip", false],
  [{name:"image.png",type:"image/png"}, "image/*", true],
  [{name:"text.txt",type:"text/plain"}, "image/*", false],
  [{name:"file.csv",type:"text/csv"}, [".zip", ".csv"], true],
  [{name:"x",type:"application/json"}, "application/json", true],
];
for (const [file, filter, expected] of cases) assert.equal(accepts(file,filter),expected);
console.log("Verified Dropzone-resolved attr-accept import and seven file-filter cases:",entry);
NODE
        audit_status=0
        npm audit --json > /reports/audit-full.json || audit_status=$?
        printf "%s\n" "$audit_status" > /reports/audit-full.exit
        audit_status=0
        npm audit --omit=dev --json > /reports/audit-production.json || audit_status=$?
        printf "%s\n" "$audit_status" > /reports/audit-production.exit
    ' > "$reports/prepare.log" 2>&1 || status=$?
cp "$candidate/awx/ui/package.json" "$reports/package.json"
cp "$candidate/awx/ui/package-lock.json" "$reports/package-lock.json"
sha256sum "$candidate/awx/ui/package.json" "$candidate/awx/ui/package-lock.json" > "$reports/ui-inputs.sha256"
printf '%s\n' "$status" > "$reports/exit-code.txt"
tail -n 45 "$reports/prepare.log"
printf 'Candidate: %s\nReports: %s (exit %s)\n' "$candidate" "$reports" "$status"
exit "$status"
