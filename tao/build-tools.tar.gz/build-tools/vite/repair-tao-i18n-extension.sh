#!/usr/bin/env bash
set -euo pipefail
source_dir=$(realpath "${1:?Pass the existing i18n candidate}")
kit=$(cd -- "$(dirname -- "$0")" && pwd)
python3 - "$source_dir/awx/ui" <<'PY'
import json, sys
from pathlib import Path
ui = Path(sys.argv[1])
assert json.loads((ui / '.linguirc').read_text())['compileNamespace'] == 'es'
p = ui / 'src/i18nLoader.js'
s = p.read_text()
old = './locales/${locale}/messages`'
new = './locales/${locale}/messages.mjs`'
if old in s:
    assert s.count(old) == 1
    p.write_text(s.replace(old, new))
else:
    assert new in s, 'Unexpected loader: no patch applied'
print('Loader uses actual Lingui4 ES output: messages.mjs')
PY
cp "$kit/probe-tao-i18n.mjs" "$source_dir/awx/ui/"
reports=$(mktemp -d "$PWD/tao-i18n-repair.XXXXXX")
printf 'Reports: %s\n' "$reports"
podman run --rm --pull=never --userns=keep-id \
  -v "$source_dir/awx/ui:/workspace:Z" -w /workspace \
  localhost/tessera-awx-application-build:24.6.1-rocky10-maintenance-final-r1 \
  bash -ec 'npm run prelint; NODE_ENV=production node probe-tao-i18n.mjs; npm run build' \
  2>&1 | tee "$reports/prepare.log"
printf 'Production translation probe and full UI build passed. Send %s/prepare.log\n' "$reports"
