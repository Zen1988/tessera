"""Correct remaining asynchronous and jsdom compatibility in subscription tests."""
from pathlib import Path
import sys

if len(sys.argv) != 2:
    raise SystemExit('Usage: python3 fix-tao-subscription-tests.py <TAO checkout>')
root = Path(sys.argv[1]) / 'awx/ui/src/screens/Setting/Subscription/SubscriptionEdit'
edits = {
    'SubscriptionEdit.test.js': [
        ("""        wrapper.find('FileUpload').invoke('onChange')(mockFile, 'mock.zip');
      });
      await act(async () => {
        wrapper.update();
      });
      await act(async () => {
        wrapper.update();
      });""", """        wrapper.find('FileUpload').invoke('onChange')(mockFile, 'mock.zip');
        await waitForElement(
          wrapper,
          'FileUploadField',
          (field) =>
            field.prop('value') === 'MTIz' &&
            field.prop('filename') === 'mock.zip'
        );
      });
      wrapper.update();"""),
        ('      const { window } = global;', '      const previousPendo = window.pendo;'),
        ("""      waitForElement(wrapper, 'Alert[title="Save successful"]');
      global.window = window;""", """      await act(async () => {
        await waitForElement(wrapper, 'Alert[title="Save successful"]');
      });
      if (previousPendo === undefined) {
        delete window.pendo;
      } else {
        window.pendo = previousPendo;
      }"""),
    ],
    'SubscriptionModal.test.js': [
        ("expect(firstRow.at(3).text()).toEqual('4/24/2024, 11:11:11 PM');",
         """expect(firstRow.at(3).text().replace(/\\u202f/g, ' ')).toEqual(
      '4/24/2024, 11:11:11 PM'
    );"""),
    ],
}
updates = {}
for name, replacements in edits.items():
    path = root / name
    original = path.read_bytes()
    newline = b'\r\n' if b'\r\n' in original else b'\n'
    text = original.replace(b'\r\n', b'\n').decode('utf-8')
    for old, new in replacements:
        if text.count(old) == 1 and new not in text:
            text = text.replace(old, new)
        elif text.count(old) == 0 and text.count(new) == 1:
            continue
        else:
            raise SystemExit(f'Unexpected test source in {path}; no writes')
    updated = text.encode('utf-8').replace(b'\n', newline)
    if updated != original:
        updates[path] = updated
for path, data in updates.items():
    path.write_bytes(data)
    print(f'Updated {path}')
print(f'Updated {len(updates)} files')
