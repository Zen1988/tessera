const fs = require('node:fs');
const path = require('node:path');
const {createRequire} = require('node:module');
const fromUI = createRequire(path.join(process.cwd(),'package.json'));
const root = process.argv[2];
fs.mkdirSync(root,{recursive:true});
const definitions = [
  {name:'lodash.get', version:'4.4.2-tessera.1', dependency:'lodash', dependencyVersion:'4.18.1', method:'get'},
  {name:'lodash.isequal', version:'4.5.0-tessera.1', dependency:'lodash', dependencyVersion:'4.18.1', method:'isEqual'},
  {name:'whatwg-encoding', version:'3.1.1-tessera.1', bundled:'@exodus/bytes@1.16.0'},
];
for(const def of definitions) {
  const folder=path.join(root,def.name);
  fs.mkdirSync(folder);
  const pkg={name:def.name,version:def.version,private:true,license:'MIT',main:'index.cjs',
    files:['index.cjs','labels.cjs','LICENSE','NOTICE'],
    tesseraCompatibilityAdapter:{implementation:def.bundled || `lodash/${def.method}@4.18.1`}};
  let upstreamRoot;
  if(def.method) {
    pkg.dependencies={lodash:def.dependencyVersion};
    fs.writeFileSync(path.join(folder,'index.cjs'),`module.exports = require('lodash/${def.method}');\n`);
    upstreamRoot=path.dirname(fromUI.resolve('lodash/package.json'));
  } else {
    // Bundle the maintained label implementation into CJS for legacy Enzyme/Jest
    // consumers. Decoding itself remains with encoding-sniffer/iconv-lite.
    upstreamRoot=path.dirname(fromUI.resolve('@exodus/bytes/encoding-lite.js'));
    const entry=path.join(process.cwd(),'tao-encoding-labels-entry.mjs');
    fs.writeFileSync(entry,"export { labelToName } from '@exodus/bytes/encoding-lite.js';\n");
    try {
      fromUI('esbuild').buildSync({entryPoints:[entry],bundle:true,platform:'neutral',format:'cjs',
        target:'es2020',outfile:path.join(folder,'labels.cjs'),legalComments:'inline'});
    } finally {fs.unlinkSync(entry);}
    fs.writeFileSync(path.join(folder,'index.cjs'),
      "const { labelToName } = require('./labels.cjs');\n"+
      "exports.labelToName = label => labelToName(String(label).trim().toLowerCase()) || null;\n");
  }
  const license=fs.readdirSync(upstreamRoot).find(name=>/^license(?:\.|$)/i.test(name));
  if(!license) throw Error('Missing implementation license: '+def.name);
  fs.copyFileSync(path.join(upstreamRoot,license),path.join(folder,'LICENSE'));
  fs.writeFileSync(path.join(folder,'NOTICE'),
    'TESSERA compatibility adapter. Uses '+(def.bundled || `lodash/${def.method}@4.18.1`)+
    '. The deprecated standalone implementation is not included.\n');
  fs.writeFileSync(path.join(folder,'package.json'),JSON.stringify(pkg,null,2)+'\n');
}
fs.writeFileSync(process.argv[3],JSON.stringify(definitions,null,2)+'\n');
