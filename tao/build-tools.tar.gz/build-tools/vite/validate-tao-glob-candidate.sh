#!/usr/bin/env bash
set -euo pipefail
candidate=$(realpath -e "${1:?Pass existing glob-r3 candidate}")
previous=$(realpath -e "${2:?Pass its preparation report directory}")
baseline=$(realpath -e "${3:?Pass the verified core-js baseline checkout}")
test -d "$baseline/awx/ui/node_modules/@lingui/cli"
baseline_hash=$(sha256sum "$baseline/awx/ui/package-lock.json")
[[ ${baseline_hash%% *} == 50eabebc0e10a0ab6ed9fe7a6927a36b6bff89f2c7912a07175b15065bc97048 ]] || {
    printf 'Baseline lock differs from accepted core-js candidate\n' >&2; exit 1;
}
kit_dir=$(cd "$(dirname "$0")" && pwd)
test -f "$previous/consumers.before.json"
reports=$(mktemp -d "$PWD/tao-glob-validation.XXXXXX")
cp "$previous/consumers.before.json" "$previous/package-lock.before.json" "$reports/"
for metadata in lingui-patch.json lingui-pack.json; do
    if [[ -f "$previous/$metadata" ]]; then cp "$previous/$metadata" "$reports/"; fi
done
cp "$kit_dir/probe-tao-glob.cjs" "$reports/"
printf 'Reports: %s\n' "$reports"
status=0
podman run --rm --pull=never --userns=keep-id --timeout=600 \
    -e npm_config_cache=/tmp/tao-npm-cache \
    -v "$candidate/awx/ui:/workspace:Z" -v "$reports:/reports:Z" -w /workspace \
    -v "$baseline/awx/ui:/baseline:ro,Z" \
    localhost/tessera-awx-application-build:24.6.1-rocky10-eslint10-r3 \
    bash -euo pipefail -c '
        node <<\NODE
const fs = require("node:fs");
const p = require("./package.json");
if(p.overrides["@lingui/cli"] !== "$@lingui/cli") throw Error("Wrong candidate CLI override");
if(p.devDependencies["@lingui/cli"] !== "file:vendor/lingui-cli-4.14.1-tessera.1.tgz") throw Error("Wrong candidate CLI");
const before = require("/reports/package-lock.before.json").packages;
const after = require("./package-lock.json").packages;
const allowedEsbuild = new Set(Object.entries(before).filter(([k]) => k.endsWith("node_modules/esbuild")).map(([,v])=>v.version));
fs.writeFileSync("/reports/lock-changes.json",JSON.stringify(Object.keys({...before,...after})
 .filter(k=>before[k]?.version!==after[k]?.version).map(k=>({path:k,before:before[k]?.version,after:after[k]?.version})),null,2));
for(const [name,pkg] of Object.entries(after)) {
 if(name.endsWith("node_modules/glob") && pkg.version!=="14.0.2") throw Error("Old/unexpected glob remains: "+name);
 if(name.endsWith("node_modules/inflight")) throw Error("inflight remains");
 if(name.endsWith("node_modules/core-js") && pkg.version.startsWith("2.")) throw Error("core-js2 reintroduced");
 if(name.endsWith("node_modules/@lingui/cli") && pkg.version!=="4.14.1-tessera.1") throw Error("Unpatched CLI remains");
 if(name.endsWith("node_modules/esbuild") && !allowedEsbuild.has(pkg.version)) throw Error("Unapproved esbuild version: "+pkg.version);
}
NODE
        npm ci --no-audit --strict-peer-deps --engine-strict
        npm run prelint
        node /reports/probe-tao-glob.cjs /reports/consumers.before.json /baseline
        node /reports/probe-tao-glob.cjs /reports/consumers.after.json
        node -e "require(\"node:assert/strict\").deepEqual(require(\"/reports/consumers.after.json\"),require(\"/reports/consumers.before.json\"))"
        npm run prelint
        audit_status=0
        npm audit --json > /reports/audit-full.json || audit_status=$?
        printf "%s\n" "$audit_status" > /reports/audit-full.exit
        audit_status=0
        npm audit --omit=dev --json > /reports/audit-production.json || audit_status=$?
        printf "%s\n" "$audit_status" > /reports/audit-production.exit
    ' > "$reports/validate.log" 2>&1 || status=$?
cp "$candidate/awx/ui/package.json" "$candidate/awx/ui/package-lock.json" "$reports/"
sha256sum "$candidate/awx/ui/package.json" "$candidate/awx/ui/package-lock.json" > "$reports/ui-inputs.sha256"
printf '%s\n' "$status" > "$reports/exit-code.txt"
tail -n 50 "$reports/validate.log"
printf 'Reports: %s (exit %s)\n' "$reports" "$status"
exit "$status"
