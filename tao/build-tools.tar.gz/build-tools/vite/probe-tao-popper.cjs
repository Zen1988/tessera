const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const {createRequire} = require('node:module');
const fromUI = createRequire(path.join(process.cwd(), 'package.json'));
const coreRoot = path.dirname(fromUI.resolve('@patternfly/react-core/package.json'));
const fromTable = createRequire(fromUI.resolve('@patternfly/react-table'));
assert.equal(fromTable.resolve('@patternfly/react-core'), fromUI.resolve('@patternfly/react-core'));
const importPattern = /(?:require\s*\(|import\s*\(|from\s+|import\s*)["'](?:tippy\.js|popper\.js)(?:\/[^"']*)?["']/;
const hashes = {};
function scan(folder, collectHashes) {
  for (const item of fs.readdirSync(folder, {withFileTypes:true})) {
    if(item.name === 'node_modules') continue;
    const file = path.join(folder,item.name);
    if(item.isDirectory()) scan(file,collectHashes);
    else if(item.isFile() && /\.(?:[cm]?jsx?|tsx?|s?css)$/.test(file)) {
      const contents = fs.readFileSync(file);
      assert(!importPattern.test(contents.toString()), 'Legacy popup import: '+file);
      if(collectHashes) hashes[path.relative(coreRoot,file)] = crypto.createHash('sha256').update(contents).digest('hex');
    }
  }
}
scan(coreRoot,true);
scan(path.join(process.cwd(),'src'),false);
assert(Object.keys(hashes).some(p=>p.includes('Tooltip/Tooltip.js')));
assert(Object.keys(hashes).some(p=>p.includes('Popover/Popover.js')));
assert(Object.keys(hashes).some(p=>p.includes('thirdparty/popper-core')));
fs.writeFileSync(process.argv[2],JSON.stringify(hashes,null,2)+'\n');
console.log('Verified no legacy popup imports and hashed',Object.keys(hashes).length,'PatternFly runtime/style/type files');
