const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const root = process.argv[2];
const pkgPath = path.join(root, 'package.json');
const pkg = JSON.parse(fs.readFileSync(pkgPath));
if (pkg.name !== '@lingui/cli' || pkg.version !== '4.14.1') throw Error('Unexpected upstream CLI');
const names = ['dist/api/catalog.js', 'dist/api/catalog/getCatalogs.js',
  'dist/extract-experimental/getEntryPoints.js', 'dist/services/translationIO.js'];
const old = 'const glob_1 = __importDefault(require("glob"));';
const replacement = 'const glob_1 = { default: require("glob").glob };';
const updates = names.map(name => {
  const content = fs.readFileSync(path.join(root, name), 'utf8');
  if (content.split(old).length !== 2) throw Error('Unexpected glob import: ' + name);
  return {name, beforeSha256: crypto.createHash('sha256').update(content).digest('hex'),
    content:content.replace(old,replacement)};
});
pkg.version = '4.14.1-tessera.1';
pkg.dependencies.glob = '14.0.2';
// Retain the previously audited esbuild override inside this reproducible package.
pkg.dependencies.esbuild = '0.25.0';
pkg.engines.node = '>=22.23.0';
for (const update of updates) fs.writeFileSync(path.join(root,update.name),update.content);
fs.writeFileSync(pkgPath, JSON.stringify(pkg,null,2)+'\n');
fs.writeFileSync(process.argv[3],JSON.stringify({upstream:'@lingui/cli@4.14.1',
  version:pkg.version, changedFiles:updates.map(({name,beforeSha256})=>({name,beforeSha256})),
  dependencies:{glob:pkg.dependencies.glob,esbuild:pkg.dependencies.esbuild}},null,2)+'\n');
