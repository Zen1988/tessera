"""Resolve Enzyme's retired Cheerio deep import through the public export."""
from pathlib import Path
import sys

if len(sys.argv) != 2:
    raise SystemExit('Usage: python3 fix-tao-enzyme-utils.py <TAO checkout>')
path = Path(sys.argv[1]) / 'awx/ui/jest.config.cjs'
original = path.read_bytes()
newline = b'\r\n' if b'\r\n' in original else b'\n'
source = original.replace(b'\r\n', b'\n')
addition = b'''
// Enzyme uses the retired deep path; use Cheerio's real public utility module.
module.exports.moduleNameMapper = {
  ...module.exports.moduleNameMapper,
  '^cheerio/lib/utils$': require.resolve('cheerio/utils'),
};
'''
if addition in source:
    print('Enzyme utility mapping already configured')
elif b'cheerio/lib/utils' in source or b'module.exports' not in source:
    raise SystemExit('Unexpected existing Cheerio mapping/config; no write')
else:
    path.write_bytes((source.rstrip(b'\n') + b'\n' + addition).replace(b'\n', newline))
    print(f'Updated {path}')
