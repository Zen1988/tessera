"""Apply reviewed PropTypes declarations; preflight every edit before writing."""
from pathlib import Path
import sys


RESOURCE = """PropTypes.shape({
      id: PropTypes.number.isRequired,
      name: PropTypes.string,
      username: PropTypes.string,
    })"""
ROLE = """PropTypes.shape({
      id: PropTypes.number.isRequired,
      name: PropTypes.string,
      description: PropTypes.string,
    })"""
OPTION = """PropTypes.shape({
      value: PropTypes.string.isRequired,
      label: PropTypes.string.isRequired,
      key: PropTypes.string.isRequired,
    })"""
EDITS = {
    'components/AdHocCommands/AdHocCommands.js': [
        ('PropTypes.arrayOf(PropTypes.object)',
         'PropTypes.arrayOf(PropTypes.shape({ name: PropTypes.string.isRequired }))'),
        ('PropTypes.arrayOf(PropTypes.array)', 'PropTypes.arrayOf(PropTypes.arrayOf(PropTypes.string))'),
    ],
    'components/AdHocCommands/AdHocCommandsWizard.js': [
        ('PropTypes.arrayOf(PropTypes.array)', 'PropTypes.arrayOf(PropTypes.arrayOf(PropTypes.string))'),
    ],
    'components/AdHocCommands/AdHocDetailsStep.js': [
        ('PropTypes.arrayOf(PropTypes.array)', 'PropTypes.arrayOf(PropTypes.arrayOf(PropTypes.string))'),
    ],
    'components/AddRole/SelectResourceStep.js': [
        ('selectedResourceRows: PropTypes.arrayOf(PropTypes.object)',
         f'selectedResourceRows: PropTypes.arrayOf({RESOURCE})'),
    ],
    'components/AddRole/SelectRoleStep.js': [
        ('roles: PropTypes.objectOf(PropTypes.object)', f'roles: PropTypes.objectOf({ROLE})'),
        ('selectedResourceRows: PropTypes.arrayOf(PropTypes.object)',
         f'selectedResourceRows: PropTypes.arrayOf({RESOURCE})'),
        ('selectedRoleRows: PropTypes.arrayOf(PropTypes.object)',
         'selectedRoleRows: PropTypes.arrayOf(\n    PropTypes.shape({ id: PropTypes.number.isRequired })\n  )'),
    ],
    'components/AppContainer/NavExpandableGroup.js': [
        ('arrayOf(PropTypes.object)', '''arrayOf(
    PropTypes.shape({
      path: string.isRequired,
      title: PropTypes.node.isRequired,
    })
  )'''),
    ],
    'components/SelectedList/SelectedList.js': [
        ('PropTypes.arrayOf(PropTypes.object)', f'PropTypes.arrayOf({RESOURCE})'),
    ],
    'screens/Application/shared/ApplicationForm.js': [
        ('authorizationOptions: PropTypes.arrayOf(PropTypes.object)',
         f'authorizationOptions: PropTypes.arrayOf({OPTION})'),
        ('clientTypeOptions: PropTypes.arrayOf(PropTypes.object)',
         f'clientTypeOptions: PropTypes.arrayOf({OPTION})'),
    ],
    'screens/Inventory/InventoryEdit/InventoryEdit.js': [
        ("import { object } from 'prop-types';", "import { arrayOf, number, shape, string } from 'prop-types';"),
        ('InventoryEdit.propType = {', 'InventoryEdit.propTypes = {'),
        ('inventory: object.isRequired', '''inventory: shape({
    id: number.isRequired,
    kind: string,
    summary_fields: shape({
      labels: shape({
        results: arrayOf(
          shape({
            id: number.isRequired,
            name: string,
          })
        ).isRequired,
      }).isRequired,
    }).isRequired,
  }).isRequired'''),
    ],
}


def main():
    if len(sys.argv) != 2:
        raise SystemExit('Usage: python3 fix-tao-proptypes.py <TAO checkout>')
    source = Path(sys.argv[1]).resolve() / 'awx/ui/src'
    updates = {}
    for name, edits in EDITS.items():
        path = source / name
        original = path.read_bytes()
        newline = b'\r\n' if b'\r\n' in original else b'\n'
        content = original.replace(b'\r\n', b'\n').decode('utf-8')
        for old, new in edits:
            if content.count(old) == 1 and new not in content:
                content = content.replace(old, new)
            elif content.count(old) == 0 and content.count(new) == 1:
                continue
            else:
                raise SystemExit(f'Unexpected declaration in {path}: {old}')
        result = content.encode('utf-8').replace(b'\n', newline)
        if result != original:
            updates[path] = result
    for path, content in updates.items():
        path.write_bytes(content)
        print(f'Updated {path}')
    print(f'Updated {len(updates)} files')


if __name__ == '__main__':
    main()
