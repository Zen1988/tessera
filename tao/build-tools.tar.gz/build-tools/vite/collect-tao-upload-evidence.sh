#!/usr/bin/env bash
set -euo pipefail
image=${1:-localhost/tessera-awx-application-build:24.6.1-rocky10-eslint10-r1}
reports=$(mktemp -d "$PWD/tao-upload-evidence.XXXXXX")
podman image inspect --format '{{.Id}}' "$image" > "$reports/image-id.txt"
podman run --rm -i --pull=never --network=none -w /build/awx/awx/ui "$image" python - \
    > "$reports/source.tar.gz" <<'PY'
from pathlib import Path
import tarfile
import sys

root = Path.cwd()
selected = set()
for name in ('package.json', 'package-lock.json', 'jest.config.cjs',
             'tao-jest-environment.cjs', 'src/setupTests.js'):
    path = root / name
    if path.is_file():
        selected.add(path)
for path in root.iterdir():
    if path.is_file() and ('lingui' in path.name.lower() or path.name.startswith('.babel')):
        selected.add(path)
for folder in ('src', 'testUtils'):
    for path in (root / folder).rglob('*'):
        if not path.is_file() or path.suffix not in ('.js', '.jsx', '.cjs', '.json'):
            continue
        name = path.relative_to(root).as_posix()
        text = path.read_text(encoding='utf-8')
        if ('/Subscription/' in name or '/FileUploadField/' in name
                or 'FileReader' in text or 'extractBabelOptions' in text
                or 'enzymeHelpers' in name or name.startswith('testUtils/')):
            selected.add(path)
if not any(p.name == 'SubscriptionStep.test.js' for p in selected):
    raise SystemExit('Missing required subscription test')
with tarfile.open(fileobj=sys.stdout.buffer, mode='w|gz') as archive:
    for path in sorted(selected):
        if path.is_symlink() or not path.resolve().is_relative_to(root):
            raise SystemExit('Source outside UI root')
        archive.add(path, arcname=path.relative_to(root), recursive=False)
print(f'Collected {len(selected)} files', file=sys.stderr)
PY
sha256sum "$reports/source.tar.gz" > "$reports/source.sha256"
printf 'Upload source.tar.gz and image-id.txt from %s\n' "$reports"
