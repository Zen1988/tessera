#!/usr/bin/env bash
set -euo pipefail
image=${1:-localhost/tessera-awx-application-build:24.6.1-rocky10-maintenance-glob-r1}
reports=$(mktemp -d "$PWD/tao-popper-callers.XXXXXX")
podman image inspect --format '{{.Id}}' "$image" > "$reports/image-id.txt"
podman run --rm -i --pull=never --network=none -w /build/awx/awx/ui "$image" python - \
    > "$reports/popper-callers.tar.gz" <<'PY'
from pathlib import Path
import json
import sys
import tarfile

root = Path.cwd()
lock = json.loads((root / 'package-lock.json').read_text())
selected = {root / 'package.json', root / 'package-lock.json'}
packages = {'tippy.js', 'popper.js', '@patternfly/react-core', '@patternfly/react-styles', '@patternfly/patternfly'}
code_suffixes = {'.js', '.jsx', '.cjs', '.mjs', '.ts', '.tsx', '.css', '.scss', '.json'}
callers = []
for folder_name, metadata in lock['packages'].items():
    package = next((name for name in packages if folder_name.endswith('node_modules/' + name)), None)
    if package is None:
        continue
    folder = root / folder_name
    if not folder.is_dir():
        raise SystemExit('Installed dependency missing: ' + folder_name)
    for path in folder.rglob('*'):
        relative = path.relative_to(folder)
        if 'node_modules' in relative.parts or not path.is_file():
            continue
        if path.name == 'package.json' or path.name.upper().startswith('LICENSE'):
            selected.add(path)
        elif path.suffix in code_suffixes:
            name = relative.as_posix().lower()
            if package in {'tippy.js', 'popper.js'} or any(word in name for word in ('tooltip', 'popover', 'popper')):
                selected.add(path)
            elif 'tippy' in path.read_text(encoding='utf-8', errors='replace').lower():
                selected.add(path)
                callers.append(path.relative_to(root).as_posix())
for path in (root / 'src').rglob('*'):
    if not path.is_file() or path.suffix not in code_suffixes:
        continue
    text = path.read_text(encoding='utf-8', errors='replace')
    if 'tippy' in text.lower() or ('@patternfly/' in text and ('Tooltip' in text or 'Popover' in text)):
        selected.add(path)
        callers.append(path.relative_to(root).as_posix())
if not callers:
    raise SystemExit('No popup callers found')
with tarfile.open(fileobj=sys.stdout.buffer, mode='w|gz') as archive:
    for path in sorted(selected):
        if path.is_symlink() or not path.resolve().is_relative_to(root):
            raise SystemExit('Source outside UI root')
        archive.add(path, arcname=path.relative_to(root), recursive=False)
print(f'Collected {len(selected)} files including {len(callers)} popup caller files', file=sys.stderr)
PY
sha256sum "$reports/popper-callers.tar.gz" > "$reports/popper-callers.sha256"
printf 'Send popper-callers.tar.gz and image-id.txt from %s\n' "$reports"
