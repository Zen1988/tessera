"""Select Node package exports for the Node-hosted Enzyme test harness."""
from pathlib import Path
import sys

if len(sys.argv) != 2:
    raise SystemExit('Usage: python3 fix-tao-jest-exports.py <TAO checkout>')
path = Path(sys.argv[1]) / 'awx/ui/jest.config.cjs'
original = path.read_bytes()
addition = b'''
// Enzyme runs in Node; keep DOM emulation but avoid browser-only ESM exports.
module.exports.testEnvironmentOptions = {
  ...module.exports.testEnvironmentOptions,
  customExportConditions: ['node', 'node-addons'],
};
'''
newline = b'\r\n' if b'\r\n' in original else b'\n'
source = original.replace(b'\r\n', b'\n')
if addition in source:
    print('Jest export conditions already configured')
elif b'customExportConditions' in source:
    raise SystemExit('Existing custom export conditions require review; no write')
elif b'module.exports' not in source:
    raise SystemExit('Unexpected Jest config; no write')
else:
    path.write_bytes((source.rstrip(b'\n') + b'\n' + addition).replace(b'\n', newline))
    print(f'Updated {path}')
