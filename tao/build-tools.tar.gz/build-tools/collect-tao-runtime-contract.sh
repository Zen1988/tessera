#!/usr/bin/env bash
set -euo pipefail
trap 'printf "Collector failed at line %s (exit %s). Preserve any report directory printed above.\n" "$LINENO" "$?" >&2' ERR
source_dir=$(realpath "${1:?Pass the final AWX source checkout}")
image=${2:-quay.io/ansible/awx:24.6.1}
if [[ ! -d "$source_dir/tools" ]]; then
    printf 'AWX source tools directory missing: %s/tools\n' "$source_dir" >&2
    exit 2
fi
reports=$(mktemp -d "$PWD/tao-runtime-contract.XXXXXX")
printf 'Reports: %s\nInspecting local image: %s\n' "$reports" "$image"
podman image inspect --format '{{.Id}} {{json .Config}}' "$image" > "$reports/upstream-image-config.txt"
# Image filesystem only: no cluster mounts, credentials, or network access.
podman run --rm --pull=never --network=none --read-only --entrypoint /bin/bash "$image" -c '
set -euo pipefail
paths=()
for p in /usr/bin/launch_awx*.sh /usr/bin/entrypoint* /usr/bin/wait-for-migrations /usr/bin/awx-manage /etc/supervisord* /etc/tower /etc/nginx /etc/rsyslog*; do
  if [[ -e "$p" ]]; then paths+=("${p#/}"); fi
done
(( ${#paths[@]} > 0 ))
tar -C / -czf - "${paths[@]}"
' > "$reports/upstream-runtime-files.tar.gz"
printf 'Collecting source runtime tools\n'
tar -C "$source_dir" -czf "$reports/source-runtime-files.tar.gz" tools
podman run --rm --pull=never --network=none --read-only --entrypoint /bin/bash "$image" -c '
id
getent passwd awx
getent group awx
rpm -qa | sort
' > "$reports/upstream-runtime-inventory.txt"
tar -C "$reports" -czf "$PWD/tao-runtime-contract.tar.gz" .
printf 'Reports: %s\nSend %s/tao-runtime-contract.tar.gz\n' "$reports" "$PWD"
