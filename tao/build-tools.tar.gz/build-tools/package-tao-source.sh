#!/usr/bin/env bash
set -euo pipefail
source_dir=$(realpath "${1:?Pass the final AWX source checkout}")
kit=$(cd -- "$(dirname -- "$0")" && pwd)
test -f "$source_dir/awx/ui/package-lock.json"
reports=$(mktemp -d "$PWD/tessera-tao-source.XXXXXX")
printf 'Packaging into: %s\n' "$reports"
python3 - "$source_dir" > "$reports/source-inputs.sha256" <<'PY'
import hashlib, json, sys
from pathlib import Path
root = Path(sys.argv[1])
ui = root / 'awx/ui'
assert json.loads((ui / '.linguirc').read_text())['compileNamespace'] == 'es'
assert './locales/${locale}/messages.mjs`' in (ui / 'src/i18nLoader.js').read_text()
vendors = sorted((ui / 'vendor').glob('*.tgz'))
assert len(vendors) >= 5, 'Expected all vendor archives'
paths = [ui / 'package.json', ui / 'package-lock.json', ui / '.linguirc',
         ui / 'src/i18nLoader.js', ui / 'vite.config.mjs', ui / 'public/index.html']
paths += vendors
paths += sorted((ui / 'public/static/media').glob('logo-*.svg'))
paths += [ui / 'public/static/media/favicon.svg']
for p in paths:
    print(hashlib.sha256(p.read_bytes()).hexdigest(), ' ', p.relative_to(root), sep='')
PY
tar -C "$source_dir" --exclude='./.git' --exclude='node_modules' \
  --exclude='./awx/ui/build' --exclude='./awx/ui/coverage' \
  --exclude='__pycache__' --exclude='*.pyc' \
  -czf "$reports/application-source.tar.gz" .
tar -tzf "$reports/application-source.tar.gz" > "$reports/source-files.txt"
tar -C "$kit" -czf "$reports/build-tools.tar.gz" build-tools REBUILD.md
if git -C "$source_dir" rev-parse HEAD > "$reports/upstream-commit.txt" 2>/dev/null; then
  git -C "$source_dir" status --short > "$reports/source-status.txt"
fi
podman image inspect --format '{{.Id}} {{json .RepoTags}}' \
  localhost/tessera-awx-application-build:24.6.1-rocky10-i18n-r1 \
  > "$reports/application-image.txt" 2> "$reports/application-image-inspect.log" || true
cp "$kit/REBUILD.md" "$reports/README.md"
(cd "$reports" && sha256sum application-source.tar.gz build-tools.tar.gz source-inputs.sha256 > SHA256SUMS)
archive="$reports.tar.gz"
tar -C "$reports" -czf "$archive" .
sha256sum "$archive" > "$archive.sha256"
printf '\nDownload BOTH:\n%s\n%s.sha256\n' "$archive" "$archive"
