# Read-only Navis field / failed upgrade diagnostic

Extract into a new folder on the Kubernetes host. From that folder run:

python3 scripts/diagnose-navis-field.py --namespace tessera --job tessera-release-1795404303 --package-plan

Paste the output. The helper clones only a terminal failed controlled upgrade Job, reusing its existing staged image/bundle, environment and mounts. It reads release metadata, package registry/journals and direct Navis field definition metadata. It prints only ID/name/type/object/validity and bounded MultiValue/config-shape flags; no field values, credentials or full configuration are printed. The original failed Job, locks, replicas and bundle PVC are retained. It does not execute package hooks, configuration rebuild, field edits, journal deletion or recovery. A journal can stop read-only planning after metadata is printed; include that output too.

The0.1.7 installer interpreted native DynamicFieldGet's empty hash (missing field) as incompatible.0.1.8 corrects the installer, but do not rerun the failed release or switch images until saved state/journals are reviewed. Redis cache errors are a separate issue; this diagnostic is not Redis repair.
