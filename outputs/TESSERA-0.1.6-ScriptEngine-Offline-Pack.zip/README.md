# TESSERA offline ScriptEngine pack — Base0.1.6

Start at AGENTS.md, then docs/scriptengine/README.md. This archive supplies exact interpreter source,
package recipes/defaults and dated native model exports. The source OPM SHA256 is in MANIFEST.json.

Run `python3 tools/verify.py` to verify all included payloads. Optional native parser/Set check:
`perl tools/validate.pl selection var/governancedb/script/governance_role_requester.yml ScriptEngine`.
Perl/YAML::XS must already be installed; no dependencies are fetched. Full runtime evaluation needs the
matching Tessera environment. `yaml` validation mode checks safe loading, not evaluation semantics.

exports/field-index.json and dynamicfields-reference.xml are derived references, not native import formats.
Package bootstrap/defaults/managed installers take precedence over dated schemas. No live site/customer/
credential data is included. Application Navis label persistence is included; complete discovery automation remains pending
where documented. Do not treat this pack as a deployment bundle or execution grant.
