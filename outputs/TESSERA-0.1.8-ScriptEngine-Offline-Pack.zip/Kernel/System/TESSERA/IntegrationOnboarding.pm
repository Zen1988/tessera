package Kernel::System::TESSERA::IntegrationOnboarding;
use strict;
use warnings;
use JSON::PP ();
use Storable qw(dclone);
use Kernel::System::TESSERA::IntegrationAuth;
our @ObjectDependencies=qw(Kernel::System::User Kernel::System::Group Kernel::System::DB Kernel::System::GenericInterface::Webservice);
sub new {my ($T,%P)=@_;bless \%P,$T}
sub Authorized {
    my ($S,$U)=@_;return if !$U;
    my %D=$Kernel::OM->Get('Kernel::System::User')->GetUserData(UserID=>$U);
    return ($D{ValidID} || 0)==1 && $Kernel::OM->Get('Kernel::System::Group')->PermissionCheck(UserID=>$U,GroupName=>'admin',Type=>'rw');
}
sub NavisRoutes {return {
    GraphBuildsList=>{Method=>'GET',Path=>'/v1/graph-builds',Parameters=>[],QueryParameters=>['namespace','limit']},
    TopologyCreate=>{Method=>'POST',Path=>'/v1/topologies',Parameters=>[],SuccessStatus=>201},
    TopologyByNameGet=>{Method=>'GET',Path=>'/v1/topologies/by-name/:Name',Parameters=>['Name'],QueryParameters=>['namespace','version_id']},
    TopologyVersionsGet=>{Method=>'GET',Path=>'/v1/topologies/by-name/:Name/versions',Parameters=>['Name'],QueryParameters=>['namespace','limit','include_audit']},
    TopologyCompareGet=>{Method=>'GET',Path=>'/v1/topologies/by-name/:Name/compare',Parameters=>['Name'],QueryParameters=>['namespace','from_version','to_version']},
    TopologyRefresh=>{Method=>'POST',Path=>'/v1/topologies/by-name/:Name/refresh',Parameters=>['Name'],QueryParameters=>['namespace']},
    TopologyGet=>{Method=>'GET',Path=>'/v1/topologies/:BuildID',Parameters=>['BuildID']},
    CollectionProgressGet=>{Method=>'GET',Path=>'/v1/ingestions/collections/:CollectionRunID',Parameters=>['CollectionRunID'],QueryParameters=>['namespace','limit','offset']},
    IngestionGet=>{Method=>'GET',Path=>'/v1/ingestions/:IngestionID',Parameters=>['IngestionID']},
    TraceGraphGet=>{Method=>'GET',Path=>'/v1/trace-sessions/:CallerSessionID/graph',Parameters=>['CallerSessionID']},
    GraphGet=>{Method=>'GET',Path=>'/v1/graph-builds/:BuildID/graph',Parameters=>['BuildID']},
    Trace=>{Method=>'POST',Path=>'/v1/traces',Parameters=>[]},
    RecommendationsGet=>{Method=>'GET',Path=>'/v1/trace-sessions/:CallerSessionID/recommendations',Parameters=>['CallerSessionID']},
    Ingest=>{Method=>'POST',Path=>'/v1/ingestions',Parameters=>[],SuccessStatus=>202},
}}
sub AWXRoutes {return {
    JobLaunch=>{Method=>'POST',Path=>'/api/v2/job_templates/:TemplateID/launch/',Parameters=>['TemplateID'],SuccessStatus=>201},
    JobLaunchCallback=>{Method=>'POST',Path=>'/api/v2/job_templates/:TemplateID/launch/',Parameters=>['TemplateID'],SuccessStatus=>201},
    WorkflowLaunch=>{Method=>'POST',Path=>'/api/v2/workflow_job_templates/:TemplateID/launch/',Parameters=>['TemplateID'],SuccessStatus=>201},
    JobGet=>{Method=>'GET',Path=>'/api/v2/jobs/:JobID/',Parameters=>['JobID']},
    WorkflowGet=>{Method=>'GET',Path=>'/api/v2/workflow_jobs/:JobID/',Parameters=>['JobID']},
    JobStdout=>{Method=>'GET',Path=>'/api/v2/jobs/:JobID/stdout/',Parameters=>['JobID'],QueryParameters=>['format','start_line','end_line']},
    JobEvents=>{Method=>'GET',Path=>'/api/v2/jobs/:JobID/job_events/',Parameters=>['JobID'],QueryParameters=>['page','page_size','order_by']},
    WorkflowNodes=>{Method=>'GET',Path=>'/api/v2/workflow_jobs/:JobID/workflow_nodes/',Parameters=>['JobID'],QueryParameters=>['page','page_size','order_by']},
}}
sub Validate {
    my ($S,$C)=@_;die "Invalid connection.\n" if ref $C ne 'HASH';
    die "Unsupported connection property.\n" if grep {!/\A(?:Preset|Origin|InstanceID|Authentication|Routes|Timeout|ConnectionUID|CustomerSimulation)\z/} keys %$C;
    die "Invalid connection identity.\n" if defined $C->{ConnectionUID} && $C->{ConnectionUID}!~/\A[a-f0-9]{40}\z/;
    die "Invalid preset.\n" if ($C->{Preset} || '')!~/\A(?:Navis|Generic|AWX)\z/;
    my $A=Kernel::System::TESSERA::IntegrationAuth->new();my $U=$A->URL($C->{Origin});
    die "HTTPS origin required.\n" if $U->path ne '' && $U->path ne '/';
    $C->{Origin}=~s{/$}{};
    $C->{Timeout}=30; # Prevent native legacy-config migration from rewriting auth.
    $A->Validate($C->{Authentication});
    die "AWX requires a mounted bearer token.\n" if $C->{Preset} eq 'AWX' && $C->{Authentication}{Provider} ne 'StaticBearer';
    die "Client credentials required for this preset.\n" if $C->{Preset} ne 'AWX' && $C->{Authentication}{Provider} ne 'ClientCredentialsBasic';
    $C->{Routes}=AWXRoutes() if $C->{Preset} eq 'AWX';
    die "Navis token endpoint must belong to this installation.\n" if $C->{Preset} eq 'Navis' && $C->{Authentication}{TokenURL} ne $C->{Origin}.'/nauth/token';
    die "Invalid instance reference.\n" if defined $C->{InstanceID} && (ref $C->{InstanceID} || length($C->{InstanceID})>255 || $C->{InstanceID}=~/[\x00-\x1f]/);
    $C->{Routes}=NavisRoutes() if $C->{Preset} eq 'Navis';
    if (exists $C->{CustomerSimulation}) {
        my $P=$C->{CustomerSimulation};
        die "Invalid customer simulation profile.\n" if $C->{Preset} ne 'Navis' || ref $P ne 'HASH'
            || grep {!/\A(?:Enabled|SourceNamespace|IdentityNamespace|GraphName)\z/} keys %$P;
        die "Invalid simulation enablement.\n" if !defined $P->{Enabled} || ref $P->{Enabled} || $P->{Enabled}!~/\A[01]\z/;
        for my $K (qw(SourceNamespace IdentityNamespace GraphName)) {
            die "Invalid simulation namespace.\n" if defined $P->{$K} && (ref $P->{$K} || length($P->{$K})>255 || $P->{$K}=~/[\x00-\x1f\x7f]/);
        }
        die "Topology name must be trimmed and nonblank.\n" if length($P->{GraphName} || '') && $P->{GraphName}=~/^\s|\s$/;
        die "A named graph requires an explicit collection namespace.\n" if length($P->{GraphName} || '') && !length($P->{SourceNamespace} || '');
        die "CMDB identity namespace required.\n" if $P->{Enabled} && !length($P->{IdentityNamespace} || '');
    }

    my $Routes=$C->{Routes};die "Operation routes required.\n" if ref $Routes ne 'HASH' || !keys %$Routes || keys(%$Routes)>32;
    for my $Name (keys %$Routes) {
        my $R=$Routes->{$Name};
        die "Invalid operation route.\n" if $Name!~/\A[A-Za-z][A-Za-z0-9]{0,63}\z/ || ref $R ne 'HASH'
            || ($R->{Method} || '')!~/\A(?:GET|POST)\z/ || ($R->{Path} || '')!~m{\A/(?!/)[A-Za-z0-9_/:.~-]+\z}
            || $R->{Path}=~m{(?:\A|/)\.\.?(/|\z)} || ref $R->{Parameters} ne 'ARRAY';
        die "Unsupported route property.\n" if grep {!/\A(?:Method|Path|Parameters|SuccessStatus|QueryParameters)\z/} keys %$R;
        die "Unsupported query parameters.\n" if exists $R->{QueryParameters} && $C->{Preset} ne 'AWX' && !($C->{Preset} eq 'Navis' && $Name=~/\A(?:GraphBuildsList|TopologyByNameGet|TopologyVersionsGet|TopologyCompareGet|TopologyRefresh|CollectionProgressGet)\z/);
        die "Invalid expected response status.\n" if defined $R->{SuccessStatus} && $R->{SuccessStatus}!~/\A20[0-9]\z/;
        my @Names=$R->{Path}=~/:([A-Za-z][A-Za-z0-9]*)/g;
        die "Invalid path parameters.\n" if join(',',sort @Names) ne join(',',sort @{$R->{Parameters}}) || grep {ref $_ || !/\A[A-Za-z][A-Za-z0-9]*\z/} @{$R->{Parameters}};
    }
    return $C;
}
sub View {
    my ($S,%P)=@_;die "Administrator access required.\n" if !$S->Authorized($P{UserID});
    my $W=$Kernel::OM->Get('Kernel::System::GenericInterface::Webservice');
    if ($P{ID}) {
        my $D=$W->WebserviceGet(ID=>$P{ID});
        die "Managed connection required.\n" if !$D || ($D->{Config}{Requester}{Transport}{Type} || '') ne 'HTTP::TESSERAIntegration';
        return $D;
    }
    my $List=$W->WebserviceList(Valid=>0) || {};my @Out;
    for my $ID (sort {$a<=>$b} keys %$List) {my $D=$W->WebserviceGet(ID=>$ID);push @Out,{ID=>$ID,Name=>$D->{Name},ValidID=>$D->{ValidID}} if ($D->{Config}{Requester}{Transport}{Type} || '') eq 'HTTP::TESSERAIntegration'}
    return \@Out;
}
sub Test {
    my ($S,%P)=@_;die "Administrator access required.\n" if !$S->Authorized($P{UserID});
    my $C=$S->Validate(dclone($P{Connection}));
    my $A=$S->{Auth} || Kernel::System::TESSERA::IntegrationAuth->new();
    my $Token=$A->Token(Profile=>$C->{Authentication},Identity=>'onboarding-test',Invalidate=>1);
    if ($C->{Preset} eq 'AWX') {
        my $R=$A->HTTP(Method=>'GET',URL=>$C->{Origin}.'/api/v2/me/',Headers=>{Authorization=>'Bearer '.$Token,Accept=>'application/json'});
        die "AWX authentication failed.\n" if ref $R ne 'HASH' || ($R->{Status} || 0)!=200 || length($R->{Body} || '')>65536;
        my $D=eval {JSON::PP->new->utf8->decode($R->{Body})};
        die "AWX identity unavailable.\n" if ref $D ne 'HASH' || ref $D->{results} ne 'ARRAY' || @{$D->{results}}!=1
            || ref $D->{results}[0] ne 'HASH' || ($D->{results}[0]{id} || '')!~/\A[1-9][0-9]*\z/;
    }
    return {Success=>1};
}
sub Save {
    my ($S,%P)=@_;die "Administrator access required.\n" if !$S->Authorized($P{UserID});
    my $C=$S->Validate(dclone($P{Connection}));
    die "Invalid connection name.\n" if !defined $P{Name} || ref $P{Name} || $P{Name}!~/\A[^\x00-\x1f]{1,100}\z/;
    $S->Test(%P) if $P{Enabled};
    my $DB=$Kernel::OM->Get('Kernel::System::DB');
    die "Onboarding busy.\n" if !$DB->Prepare(SQL=>q{SELECT GET_LOCK('tessera_integration_onboarding',5)});
    my @Lock=$DB->FetchrowArray();die "Onboarding busy.\n" if !$Lock[0];
    my ($ID,$Error);eval {
        my $W=$Kernel::OM->Get('Kernel::System::GenericInterface::Webservice');
        my $Existing=$P{ID}?$S->View(UserID=>$P{UserID},ID=>$P{ID}):undef;
        require Crypt::PRNG;
        $C->{ConnectionUID}=$Existing?$Existing->{Config}{Requester}{Transport}{Config}{ConnectionUID}:unpack('H*',Crypt::PRNG::random_bytes(20));
        my $List=$W->WebserviceList(Valid=>0) || {};
        die "Name already exists; select its managed connection.\n" if grep {$List->{$_} eq $P{Name} && (!$Existing || $_!=$P{ID})} keys %$List;
        my %I=map {$_=>{Type=>$C->{Preset} eq 'AWX'?'AWX::'.$_:'TESSERA::Request',MappingInbound=>{},MappingOutbound=>{}}} keys %{$C->{Routes}};
        if ($P{Enabled} && ref $C->{CustomerSimulation} eq 'HASH' && $C->{CustomerSimulation}{Enabled}) {
            for my $Other (keys %$List) {
                next if $P{ID} && $Other==$P{ID};
                my $W=$W->WebserviceGet(ID=>$Other);
                die "Another customer simulation connection is enabled.\n" if $W && ($W->{ValidID} || 0)==1
                    && ($W->{Config}{Requester}{Transport}{Config}{Preset} || '') eq 'Navis'
                    && $W->{Config}{Requester}{Transport}{Config}{CustomerSimulation}{Enabled};
            }
        }
        my $Config={Debugger=>{DebugThreshold=>'error',TestMode=>0},Requester=>{Invoker=>\%I,Transport=>{Type=>'HTTP::TESSERAIntegration',Config=>$C}}};
        my %Args=(Name=>$P{Name},Config=>$Config,ValidID=>$P{Enabled}?1:2,UserID=>$P{UserID});
        if ($Existing) {$ID=$P{ID};die "Service update failed.\n" if !$W->WebserviceUpdate(ID=>$ID,%Args)}
        else {$ID=$W->WebserviceAdd(%Args);die "Service creation failed.\n" if !$ID}
        1;
    } or $Error=$@ || 'Service save failed.';
    $DB->Prepare(SQL=>q{SELECT RELEASE_LOCK('tessera_integration_onboarding')});$DB->FetchrowArray();
    die $Error if $Error;return $ID;
}
1;
