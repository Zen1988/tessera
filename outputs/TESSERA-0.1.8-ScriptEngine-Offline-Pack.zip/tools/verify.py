from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parents[1]
doc=json.loads((root/'MANIFEST.json').read_text(encoding='utf-8'))
for name,row in doc['files'].items():
 p=(root/name).resolve();assert p.is_relative_to(root),name
 assert p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],name
print('Verified',len(doc['files']),'files for Base'+doc['version'])
