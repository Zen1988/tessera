use strict;use warnings;
use FindBin;use lib "$FindBin::Bin/..";
use Encode qw(decode FB_CROAK);use JSON::PP ();
use Kernel::System::TESSERA::ScriptEngine;
use Kernel::System::TESSERA::ScriptBlocks qw(SplitSource Assemble);
my ($Kind,$File,$Field)=@ARGV;$Field ||= 'ScriptEngine';
die "Usage: perl tools/validate.pl selection|yaml source.yml [SetName]\n" if !$File || ($Kind ne 'selection' && $Kind ne 'yaml');
open my $F,'<:raw',$File or die "Cannot open source\n";local $/;my $Source=decode('UTF-8',<$F>,FB_CROAK);close $F;
my $E=Kernel::System::TESSERA::ScriptEngine->new();my $Doc=$E->ScriptSourceLoad(Source=>$Source);
if ($Kind eq 'selection') {my $R=$E->ScriptParse(Script=>$Doc);die "$R->{Error}\n" if !$R->{Success};}
my $Rows=SplitSource(Field=>$Field,Source=>$Source);
die "Set assembly changed source\n" if Assemble(Field=>$Field,Rows=>$Rows) ne $Source;
print JSON::PP->new->canonical->encode({Success=>1,Validation=>$Kind eq 'selection'?'ScriptParse plus Set round-trip':'Safe YAML loading plus Set round-trip only',Blocks=>scalar @$Rows,SourceCharacters=>length($Source),RuntimeEvaluation=>0}),"\n";
