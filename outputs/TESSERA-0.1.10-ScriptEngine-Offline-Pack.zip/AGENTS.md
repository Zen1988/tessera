# TESSERA offline authoring contract — Base0.1.10

Work offline. Read README.md, MANIFEST.json, docs/scriptengine/workflow.md and language.md first.
Use exact included OPM source/defaults, then native schema exports, then prose. Dated exports are not live site truth.
Never invent field/class/catalogue/service names or IDs. Preserve FieldAsssignment and Contract-SupportProfie spellings.
Identify caller, programming object, runtime target, storage Set and typed return before writing source.
Unknown/ambiguous/overflow/unauthorized outcomes fail closed. No SQL/shell/arbitrary HTTP or credential literals.
TESSERA::* capabilities never execute resolver programs. A script parser is not authorization or publication approval.
Use source and tools/validate.pl for real parsing/Set assembly; use tools/verify.py for file integrity.
Deliver source, ordered blocks, exact dependencies, negative tests and runtime review/installation notes.
Verify managed additions such as Application Navis against installer source; do not claim absent adapters or automation schedulers exist. Check documented limitations.
No internet, package install, live connection or mutation is required to read and author with this pack.
